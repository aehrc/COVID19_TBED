#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports

# Internal imports

#------------------- Constants ------------------------------#

TYPE_COL_NAME   = 'type'
REF_LABEL       = 'ref'
TARGET_LABEL    = 'target'

IS_TARGET_LABEL    = 'isTarget'
IS_PARTIAL_LABEL   = 'isPartial'
IS_SOURCE_LABEL    = 'isSource'

#------------------- Public Classes & Functions -------------#

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
