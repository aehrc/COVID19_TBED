#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, FastICA
from sklearn.manifold import Isomap, TSNE

# Internal imports
from ...kmer.constants import FILE_COL_NAME
from ...util import spark
from .constants import *

#------------------- Constants ------------------------------#

## Number of dataframes processed in parallel
CHUNK_SIZE = 1000

#------------------- Public Classes & Functions -------------#

def run(rFreq, *tFreqs):
    print("Running PCA")
    pipe  = getPipeline()

    ## We are only explaining about 70% of the variance 
    ## with 2D PCA (not great, but works relatively OK)
    rPca  = pipe.fit_transform(rFreq)
    # print(pipe.steps[1][1].explained_variance_ratio_)

    if (len(tFreqs) != 0):
        tPcas  = transform(pipe, tFreqs)
        return (rPca, tPcas, PCA_DATA_COL_NAMES)

    return (rPca, PCA_DATA_COL_NAMES)

#------------------- Private Classes & Functions ------------#

def getPipeline():
    ## Set up PCA pipeline
    ## 1. Scale variables
    ## 2. Apply PCA
    pipe = Pipeline([('scaler', StandardScaler()),
                     ('reducer', PCA(n_components=N_PCA_COMPONENTS))
                     # ('reducer', FastICA(n_components=N_PCA_COMPONENTS))
                     # ('reducer', Isomap(n_components=N_PCA_COMPONENTS))
                     # ('reducer', TSNE(n_components=N_PCA_COMPONENTS))
                     ])
    return pipe

def transform(pipe, tFreqs):
    tPcas = []

    with spark.getSparkContext() as sc:
        ## Split every smaller tKmerFreq chunk into even smaller chunks
        ## that we can process. Chunking performance (time & memory) is 
        ## basically the same as without chunking. But chunking
        ## minimises the amount of memory required by Spark
        for i in range(0, len(tFreqs), CHUNK_SIZE):
            tFreqsChunk = tFreqs[i:i + CHUNK_SIZE]

            ## Data must fit in available memory!
            rdd = sc.parallelize(tFreqsChunk)
            rdd = rdd.cache()

            ## Get the PCAs for each record in parallel with Spark
            ## Result must fit in available memory!
            f        = lambda x: pipe.transform(x)
            newtPcas = rdd.map(f).collect()
            tPcas    = tPcas + newtPcas

    return tPcas

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
