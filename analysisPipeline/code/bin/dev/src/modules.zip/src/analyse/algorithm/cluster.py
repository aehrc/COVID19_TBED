#!/bin/python

#------------------- Description & Notes --------------------#

'''
There are different approaches to model selection
See: https://stackoverflow.com/questions/39920862/model-selection-for-gaussianmixture-by-using-gridsearch

Unlike other clustering algorithms that tell us which data point belongs to 
which cluster, Gaussian mixture models tell us the probabilities that 
a data point belongs to each cluster.
'''

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import GridSearchCV

# Internal imports
from ...util import spark
from .constants import *

#------------------- Constants ------------------------------#

MAX_NUM_CLUSTERS = 50

#------------------- Public Classes & Functions -------------#

def run(pca, plotPerf=False):
    print("Running clustering")
    mPerf     = getModelPerformanceTable(pca)
    if (plotPerf):
        print("Drawing model performance line")
        plotPerformance(mPerf)

    nClusters = selectModel(mPerf)
    print("Num. Clusters:\t" + str(nClusters))

    cMethod = fit(pca, nClusters)
    cLabels = cMethod.predict(pca)
    cLabels = np.reshape(cLabels, (-1, 1))
    # print(cMethod.cluster_centers_)

    return (cLabels, [CLUSTER_COL_NAME])

def getModelPerformanceTable(pca):
    nClusters = range(2, MAX_NUM_CLUSTERS)

    with spark.getSparkContext() as sc:
        ## Data must fit in available memory!
        rdd = sc.parallelize(nClusters)
        rdd = rdd.cache()

        ## Get the scores for each nCluster in parallel with Spark
        ## Result must fit in available memory!
        f      = lambda x: calculateScores(pca, x)
        mPerfs = rdd.map(f).collect()

    mPerf = pd.concat(mPerfs, ignore_index=True)
    mPerf.columns = [NCLUSTERS_COL_NAME, BIC_COL_NAME, AIC_COL_NAME]
    return mPerf

#------------------- Private Classes & Functions ------------#

def plotPerformance(mPerf):
    mPerf.plot(x=NCLUSTERS_COL_NAME, y=[BIC_COL_NAME, AIC_COL_NAME])
    plt.show()

def calculateScores(pca, nClusters):
    cMethod  = fit(pca, nClusters)

    ## Supposedly metrics for assessing the number of components to use
    ## https://jakevdp.github.io/PythonDataScienceHandbook/05.12-gaussian-mixtures.html
    BICScore = cMethod.bic(pca)
    AICScore = cMethod.aic(pca)
    scores   = pd.DataFrame([[nClusters, BICScore, AICScore]])
    return scores

def fit(pca, nClusters):
    ## Gaussian Mixture is not necessarily a clustering algorithm,
    ## But instead, an algorithm for density estimation
    cMethod = GaussianMixture(n_components=nClusters, random_state=0)
    cMethod = cMethod.fit(pca)
    return cMethod

def selectModel(mPerf):
    ## Choose the number of clusters based on the BIC score
    ## Lower BIC score = better
    minBicIdx = mPerf[BIC_COL_NAME].idxmin()
    nClusters = mPerf.loc[minBicIdx, NCLUSTERS_COL_NAME].astype(int)
    return nClusters

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
