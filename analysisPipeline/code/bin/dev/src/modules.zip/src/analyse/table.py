#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pandas as pd

# Internal imports
from ..kmer.constants import ID_COL_NAME
from .constants import *

#------------------- Constants ------------------------------#

POSITIONS_ID_LENGTH = 8

#------------------- Public Classes & Functions -------------#

def addPcaColumns(pcaArray, kmerFreq):
    t = addColumns(pcaArray, kmerFreq, PCA_DATA_COL_NAMES)
    return t

def addDensityColumn(densityArray, kmerFreq):
    t = addColumns(densityArray, kmerFreq, [DENSITY_PROB_COL_NAME])
    return t

def addDensityLabelColumn(densityArray, kmerFreq):
    t = addColumns(densityArray, kmerFreq, [DENSITY_LABEL_COL_NAME])
    return t

def addClusterColumn(clusterArray, kmerFreq):
    t = addColumns(clusterArray, kmerFreq, [CLUSTER_COL_NAME])
    t[CLUSTER_COL_NAME].astype(str)
    return t

def addOutlierColumn(outlierArray, kmerFreq):
    t = addColumns(outlierArray, kmerFreq, [OUTLIER_COL_NAME])
    return t

#------------------- Private Classes & Functions ------------#

def addColumns(array, kmerFreq, columnNames):

    '''
    Args:
        array (np.ndarray):
            [[  -7.89444622 ... -20.82256807 ]
             [ -27.74461018 ...  23.5397721  ]
             [  22.02011738 ...   5.04338776 ]
                   ...          
             [  31.1867031  ...   4.94984223 ]
             [ -17.56776408 ... -12.71043402 ]]

        kmerFreq (pd.DataFrame):
               filename
            0  file.txt
        
        columnNames (List<String>):
            [column1, column2, column3]

    Returns:
        table (pd.DataFrame):
                  filename    column1    column2
            0   file_1.txt  -7.894446 -20.822568
            1   file_2.txt -27.744610  23.539772
    '''

    t = pd.DataFrame(array, columns=columnNames)
    t = pd.concat([kmerFreq, t], axis=1)
    return t

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
