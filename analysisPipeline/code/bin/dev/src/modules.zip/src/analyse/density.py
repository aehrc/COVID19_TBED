#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pandas as pd
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.neighbors import KernelDensity

# Internal imports
from ..kmer.constants import FILE_COL_NAME
from ..util import spark
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(rKmerId, rPca, **tCols):
    #tIdCols=None, tPcas=None):
    #rKmerPca, tKmerPcas=None):

    print("Running density estimation")
    fNames = rKmerId[FILE_COL_NAME].unique().tolist()
    rPcas  = [getPcaSubset(rKmerId, rPca, f) for f in fNames]
    (bws, rDen) = fit(fNames, rPcas)

    # if (tKmerPcas is not None):
    #     tDens = predict(kdes, tKmerPcas)
    #     return (bws, rDen, tDens)

    return (bws, rDen)

#------------------- Private Classes & Functions ------------#

def fit(fNames, pcas):
    ## Calculate the density on each data subset
    bws  = [(fName, selectBandwidth(pca)) for fName, pca in zip(fNames, pcas)]
    kdes = [getKde(pca, bw[1]) for pca, bw in zip(pcas, bws)]
    zs   = [getScore(pca, kde) for pca, kde in zip(pcas, kdes)]
    den  = np.concatenate(zs)
    return (bws, den)

def getPcaSubset(kmerId, pca, f):
    isFile       = (kmerId[FILE_COL_NAME] == f)
    kmerIdSubset = kmerId[isFile]
    pcaSubset    = pca[kmerIdSubset.index.values, :]
    return pcaSubset

def selectBandwidth(pca):
    ## 20-fold cross-validation
    grid = GridSearchCV(KernelDensity(kernel='gaussian'),
        {'bandwidth': np.linspace(0.1, 1.0, 30)}, cv=20)
    grid.fit(pca)
    return grid.best_params_['bandwidth']

def getKde(pca, bw):
    kde = KernelDensity(kernel='gaussian', bandwidth=bw)
    kde = kde.fit(pca)
    return kde

def getScore(pca, kde):
    z = np.exp(kde.score_samples(pca))
    z = np.reshape(z, (-1, 1))
    return z

def predict(kdes, tKmerPcas):
    ## Calculate the posterior probability of a data point
    ## belonging to a density and find the density with the highest probability
    ## https://stats.stackexchange.com/questions/186269/probabilistic-classification-using-kernel-density-estimation
    with spark.getSparkContext() as sc:
        ## Data must fit in available memory!
        rdd = sc.parallelize(tKmerPcas)
        rdd = rdd.cache()

        ## Get the probability for each data point in parallel with Spark
        ## Result must fit in available memory
        f      = lambda x: calculateProbability(kdes, x)
        tProbs = rdd.map(f) \
                    .collect()

    g       = lambda x: np.argmax(x, axis=1)
    tLabels = list(map(g, tProbs))
    tDen    = np.hstack((tProbs, tLabels)) ## Probabilities & Labels
    return tLabels

def calculateProbability(kdes, kmerPca):
    xy = getXY(kmerPca)

    ## Calculate the score (i.e., probability) of new data points
    ## https://stackoverflow.com/questions/24681825/kernel-density-score-vs-score-samples-python-scikit
    scores  = [np.exp(k.score_samples(xy)) for k in kdes]
    scores  = [np.reshape(s, (-1, 1)) for s in scores]
    scores  = np.hstack((scores[0], scores[1]))
    probSum = np.sum(scores, axis=1)

    prob1 = np.divide(scores[:, 0], probSum, where=probSum != 0)
    prob1 = np.reshape(prob1, (-1, 1))
    prob2 = np.divide(scores[:, 1], probSum, where=probSum != 0)
    prob2 = np.reshape(prob2, (-1, 1))
    probs = np.hstack((prob1, prob2))
    return probs

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
