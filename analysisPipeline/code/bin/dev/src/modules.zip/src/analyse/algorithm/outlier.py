#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM

# Internal imports
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(pca):
    print("Running outlier detection")
    # oMethod = IsolationForest()
    # oMethod = LocalOutlierFactor()
    oMethod = OneClassSVM(kernel='linear')      
    ## Linear kernal is decent but essentially a splits the plot
    ## with a line. Is there a way to split the plot with a polynominal?
    ## Problem is that the poly kernal took a long time to run!
    ## Might need to revisit this
    oLabels = oMethod.fit_predict(pca)
    oLabels = np.reshape(oLabels, (-1, 1))
    return (oLabels, [OUTLIER_COL_NAME])

#------------------- Private Classes & Functions ------------#



#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
