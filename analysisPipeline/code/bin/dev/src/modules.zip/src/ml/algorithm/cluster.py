#!/bin/python

#------------------- Description & Notes --------------------#

'''
There are different approaches to model selection
See: https://stackoverflow.com/questions/39920862/model-selection-for-gaussianmixture-by-using-gridsearch

Unlike other clustering algorithms that tell us which data point belongs to
which cluster, Gaussian mixture is a density estimation algorithm that tells
us the probabilities that a data point belongs to each cluster.

Spectral Clustering looks really good on filtered data, but very inefficient!
DBSCAN is basically a faster version of Spectral Clustering, whereas OPTICS
is a more efficient version of DBSCAN. Unfortunately, I always encounter
a division by 0 error with OPTICS!

'''

#------------------- Dependencies ---------------------------#

# Standard library imports
from itertools import product

# External imports
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import DBSCAN
from sklearn.cluster import OPTICS
from sklearn.cluster import SpectralClustering
from sklearn.metrics import silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.model_selection import GridSearchCV

# Internal imports
from ...util import spark
from .constants import *

#------------------- Constants ------------------------------#

## Constants for assessing the performance of clustering
NCLUSTERS_COL_NAME    = 'nClusters'
BIC_COL_NAME          = 'BIC'
BIC_GRADIENT_COL_NAME = 'BICGradient'
AIC_GRADIENT_COL_NAME = 'AICGradient'
AIC_COL_NAME          = 'AIC'
SIL_COL_NAME          = 'Silhouette'

#------------------- Public Classes & Functions -------------#

def run(pca):
    ## Hyperparameter tuning
    cMethod = getOptimalMethod(pca)

    ## Perform clustering
    cLabels = getClusterLabels(cMethod, pca)
    cLabels = np.reshape(cLabels, (-1, 1))
    # print(cMethod.cluster_centers_)

    return (cLabels, [CLABEL_COL_NAME])

#------------------- Private Classes & Functions ------------#

def getOptimalMethod(pca, plotPerf=False):
    ## Create models for other methods if required
    # cMethod = OPTICS()
    # cMethod = AgglomerativeClustering(n_clusters=nClusters, linkage='average')
    # cMethod = AgglomerativeClustering(n_clusters=nClusters, linkage='ward')

    # cModel = GaussianModel(pca)
    cModel = DBSCANModel(pca)
    # cModel = SpectralModel(pca)

    cModel.tuneHyperparameters()
    if (plotPerf):
        print("Plotting performance")
        cModel.plotPerformance()

    cMethod = cModel.selectOptimalMethod()
    return cMethod

def getClusterLabels(cMethod, pca):
    if (hasattr(cMethod, 'labels_')):
        cLabels = cMethod.labels_.astype(np.int)
    else:
        cLabels = cMethod.predict(pca)
    return cLabels

class Model():

    ## Maximum number of clusters
    MAX_NUM_CLUSTERS   = 50
    MAX_NUM_ITERATIONS = 20

    def __init__(self, pca):
        self.pca = pca

    def tuneHyperparameters(self):
        params = self.getHyperParameters()

        with spark.getSparkContext() as sc:
            rdd = sc.parallelize(params)

            ## Get the scores for each parameter combination in parallel with Spark
            ## Result must fit in available memory!
            f = lambda x, y: pd.concat([x, y], ignore_index=True)
            self.perfScores = rdd.map(self.getMethod) \
                                 .map(self.getScores) \
                                 .reduce(f)

    def getScores(self, cMethod):
        scores = [self.calculateScores(cMethod)
                  for n in range(self.MAX_NUM_ITERATIONS)]
        scores = pd.concat(scores, ignore_index=True)
        scores = self.groupScores(scores)
        return scores

    def getHyperParameters(self):

        """
        Description:
            Generates a list of all parameter combinations.

        Returns:
            params (list):
                List of tuples, where each tuple contains the parameters used

        Raises:
            ValueError:
                If kmerLength is not a positive integer.
        """

        pass

    def getMethod(self, param):

        """
        Description:
            Generates a new algorithm instance

        Returns:
            cMethod (Obj):
                Algorithm instance
        """

        pass

    def calculateScores(self, cMethod):

        """
        Description:
            Calculates performance scores

        Returns:
            scores (pd.DataFrame):
                Row containing performance scores

        """

        pass

    def groupScores(self, scores):
        pass

    def plotPerformance(self):
        pass

    def selectOptimalMethod(self):
        pass

#------------------------------------------------------------#

class GaussianModel(Model):

    def __init__(self, pca):
        Model.__init__(self, pca)

    def getHyperParameters(self):
        ## The only hyperparameter we are interested
        ## is the number of clusters to use
        nClusters = range(2, self.MAX_NUM_CLUSTERS)
        params    = list(product(eps, samples))
        return params

    def getMethod(self, param):
        nClusters = param[0]  ## We know that nClusters is the only parameter

        cMethod   = GaussianMixture(n_components=nClusters, n_init=10)
        cMethod   = cMethod.fit(self.pca)
        return cMethod

    def calculateScores(self, cMethod):
        ## Supposedly metrics for assessing the number of components to use
        ## https://jakevdp.github.io/PythonDataScienceHandbook/05.12-gaussian-mixtures.html
        BICScore  = cMethod.bic(self.pca)
        AICScore  = cMethod.aic(self.pca)
        nClusters = cMethod.n_components

        scores   = pd.DataFrame([[nClusters, BICScore, AICScore]])
        scores.columns = [NCLUSTERS_COL_NAME, BIC_COL_NAME, AIC_COL_NAME]
        return scores

    def groupScores(self, scores):
        scores = scores.groupby([NCLUSTERS_COL_NAME], as_index=False).mean()
        return scores

    def plotPerformance(self):
        self.addGradientColumn()

        ## Plot BIC/AIC scores
        y = [BIC_COL_NAME, AIC_COL_NAME]
        self.perfScores.plot(x=NCLUSTERS_COL_NAME, y=y)
        plt.show()

        ## Plot BIC/AIC gradients
        y = [BIC_GRADIENT_COL_NAME, AIC_GRADIENT_COL_NAME]
        self.perfScores.plot(x=NCLUSTERS_COL_NAME, y=y)
        plt.show()

    def addGradientColumn(self):
        BICScores = self.perfScores.loc[:, BIC_COL_NAME]
        AICScores = self.perfScores.loc[:, AIC_COL_NAME]
        self.perfScores[BIC_GRADIENT_COL_NAME] = np.gradient(BICScores)
        self.perfScores[AIC_GRADIENT_COL_NAME] = np.gradient(AICScores)
        return self.perfScores

    def selectOptimalMethod(self):
        ## Choose the number of clusters based on the BIC score
        ## BIC seems a bit better / more popular than the AIC score

        ## Approch 1:
        # ## Lower BIC score = better
        # minBicIdx = self.perfScores[BIC_COL_NAME].idxmin()
        # nClusters = self.perfScores.loc[minBicIdx, NCLUSTERS_COL_NAME].astype(int)

        ## Approach 2:
        ## Automating the 'Elbow Rule'
        ## https://www.datasciencecentral.com/profiles/blogs/how-to-automatically-determine-the-number-of-clusters-in-your-dat
        bicColumn = self.perfScores.loc[:, BIC_COL_NAME]
        delta1    = bicColumn.diff() * -1
        delta2    = delta1.diff() * -1
        strength  = delta2 - delta1
        strength  = strength.shift(-1)

        idx       = strength.idxmax()   ## Higher strength == better
        nClusters = self.perfScores.loc[idx, NCLUSTERS_COL_NAME].astype(int)
        cMethod   = self.getMethod((nClusters,))
        print("Num. Clusters:\t" + str(nClusters))
        return cMethod

#------------------------------------------------------------#

class DBSCANModel(Model):

    def __init__(self, pca):
        Model.__init__(self, pca)

    def getHyperParameters(self):
        eps     = np.arange(0.5, 5, 0.5)
        params  = list(product(eps))
        return params

    def getMethod(self, param):
        ## We don't have any parameters that we need to tune
        eps     = param[0]

        cMethod = DBSCAN(eps=eps, n_jobs=-1)
        cMethod = cMethod.fit(self.pca)
        return cMethod

    def calculateScores(self, cMethod):
        cLabels  = getClusterLabels(cMethod, self.pca)
        silScore = silhouette_score(self.pca, cLabels)
        eps      = cMethod.eps

        scores   = pd.DataFrame([[eps, silScore]])
        scores.columns = [EPS_COL_NAME, SIL_COL_NAME]
        return scores

    def groupScores(self, scores):
        scores = scores.groupby([EPS_COL_NAME], as_index=False).mean()
        return scores

    def plotPerformance(self):
        print(self.perfScores)
        ## Plot Silhouette scores
        y = [SIL_COL_NAME]
        self.perfScores.plot(x=EPS_COL_NAME, y=y)
        plt.show()

    def selectOptimalMethod(self):
        idx     = self.perfScores.loc[:, SIL_COL_NAME].idxmax()
        eps     = self.perfScores.loc[idx, EPS_COL_NAME].astype(float)
        cMethod = self.getMethod((eps, ))
        print("EPS:\t" + str(eps))
        return cMethod

#------------------------------------------------------------#

class SpectralModel(Model):

    def __init__(self, pca):
        Model.__init__(self, pca)

    def getHyperParameters(self):
        ## The only hyperparameter we are interested
        ## is the number of clusters to use. But it
        ## takes too long to run all combinations!
        nClusters = range(2, 4)
        params    = list(product(eps, samples))
        return params

    def getMethod(self, param):
        nClusters = param[0]  ## We know that nClusters is the only parameter

        cMethod   = SpectralClustering(n_clusters=nClusters, n_init=10)
        cMethod   = cMethod.fit(self.pca)
        return cMethod

    def calculateScores(self, cMethod):
        cLabels   = getClusterLabels(cMethod, self.pca)
        silScore  = silhouette_score(self.pca, cLabels)
        nClusters = cMethod.n_clusters

        scores   = pd.DataFrame([[nClusters, silScore]])
        scores.columns = [NCLUSTERS_COL_NAME, SIL_COL_NAME]
        return scores

    def groupScores(self, scores):
        scores = scores.groupby([NCLUSTERS_COL_NAME], as_index=False).mean()
        return scores

    def plotPerformance(self):
        ## Plot Silhouette scores
        y = [SIL_COL_NAME]
        self.perfScores.plot(x=NCLUSTERS_COL_NAME, y=y)
        plt.show()

    def selectOptimalMethod(self):
        idx       = self.perfScores.loc[:, SIL_COL_NAME].idxmax()
        nClusters = self.perfScores.loc[idx, NCLUSTERS_COL_NAME].astype(int)
        cMethod   = self.getMethod((nClusters,))
        print("Num. Clusters:\t" + str(nClusters))
        return cMethod

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
