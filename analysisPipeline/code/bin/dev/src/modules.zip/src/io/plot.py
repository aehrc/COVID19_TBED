#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os

# External imports
import holoviews as hv
import plotly

# Internal imports
from .constants import *
from .common import createDirIfNone
from .common import removeFileIfExists

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def write(filepath, figure, fType):
    if (fType == HISTOGRAM):
        _writeHistogram(filepath, figure)

    elif(fType == SCATTER):
        _writeScatter(filepath, figure)

    else:
        raise NotImplementedError("Plot type not recognised!")

#------------------- Private Classes & Functions ------------#

def _writeHistogram(filepath, figure):
    _writeFigure(filepath, figure)

def _writeScatter(filepath, figure):
    if (figure.in2D):
        _writeFigure(filepath, figure)

    else:
        ## Create DIR if it doesnt exist
        outputDir = os.path.dirname(filepath)
        createDirIfNone(outputDir)
        removeFileIfExists(filepath)

        # ## 3D plots can't be done with Bokeh
        # ## Must be done with either Matplotlib or Plotly

        # ## I don't know why hv.save doesn't work properly
        # hv.save(figure.layout, filepath)

        ## Instead of holoviews, we have to rely on plotly for outputting
        ## 3D plots are nice but don't really work well
        ## https://github.com/pyviz/holoviews/issues/1819
        objstate = hv.renderer('plotly').get_plot(figure.layout).state

        ## Manually customise the plot (via plotly)
        layoutDict = objstate['layout']
        layoutDict['width']  = 1500
        layoutDict['height'] = 1500

        ## Output plot
        plotly.offline.plot(objstate, filename=filepath)

def _writeFigure(filepath, figure):
    ## Create DIR if it doesnt exist
    outputDir = os.path.dirname(filepath)
    createDirIfNone(outputDir)
    removeFileIfExists(filepath)
    hv.save(figure.layout, filepath)

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
