#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import glob
import os
import shutil
import sys
from pathlib import Path

# External imports
from Bio import SeqIO
import holoviews as hv
import pandas as pd
import plotly

# Internal imports

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def writeKmerFrequencies(filepath, kmerDf):
    ## Ensure that our file is written correctly and consistently
    createDirIfNone(filepath)       ## Create DIR if it does not exist
    removeFileIfExists(filepath)    ## Remove FILE if it exist

    ## Write the table to file in PARQUET format
    ## We can change the format in the future if it doesn't work out...
    tmpDir = getTempDir(filepath)
    kmerDf.write.parquet(tmpDir, mode='overwrite', compression="snappy")

    ## Rename and move all output files
    p = os.path.join(tmpDir, "*.snappy.parquet")
    [os.rename(f, filepath) for i, f in enumerate(glob.glob(p), 1)]

    ## Cleanup
    shutil.rmtree(tmpDir, ignore_errors=True)

def writeFastX(filepath, seqRecords, fastXtype):
    ## Create DIR if it doesnt exist
    outputDir = os.path.dirname(filepath)
    createDirIfNone(outputDir)
    removeFileIfExists(filepath)
    SeqIO.write(seqRecords, filepath, fastXtype)

def writeFigure(filepath, figure):
    ## Create DIR if it doesnt exist
    outputDir = os.path.dirname(filepath)
    createDirIfNone(outputDir)
    removeFileIfExists(filepath)
    hv.save(figure.layout, filepath)

def writePca(filepath, pca):
    ## Create DIR if it doesnt exist
    outputDir = os.path.dirname(filepath)
    createDirIfNone(outputDir)
    removeFileIfExists(filepath)
    pca.to_csv(filepath,
        index=False, sep='\t')

def writePcaFigure(filepath, figure):
    if (figure.is2D()):
        writeFigure(filepath, figure)

    else:
        ## Create DIR if it doesnt exist
        outputDir = os.path.dirname(filepath)
        createDirIfNone(outputDir)
        removeFileIfExists(filepath)

        # ## 3D plots can't be done with Bokeh
        # ## Must be done with either Matplotlib or Plotly

        # ## I don't know why hv.save doesn't work properly
        # hv.save(figure.layout, filepath)

        ## Instead of holoviews, we have to rely on plotly for outputting
        ## 3D plots are nice but don't really work well
        ## https://github.com/pyviz/holoviews/issues/1819
        objstate = hv.renderer('plotly').get_plot(figure.layout).state

        ## Manually customise the plot (via plotly)
        layoutDict = objstate['layout']
        layoutDict['width']  = 1500
        layoutDict['height'] = 1500

        ## Output plot
        plotly.offline.plot(objstate, filename=filepath)

#------------------- Private Classes & Functions ------------#

def createDirIfNone(filepath):
    p = Path(os.path.dirname(filepath))
    p.mkdir(parents=True, exist_ok=True)

def removeFileIfExists(filepath):
    p = Path(filepath)
    if (os.path.exists(filepath)):
        p.unlink()

def getTempDir(filepath):
    filename = os.path.basename(filepath)
    tmpDir   = filename.split(".")[0]
    return "." + tmpDir

def isValidTempDir(filepath):
    ## Check that we can safely write the output
    tmpDir = getTempDir(filepath)
    if (os.path.exists(tmpDir)):
        errMsg = """Temp directory ({}) exists. Might be important, 
                    so we better not continue. Please remove
                 """.format(tmpDir)
        raise NameError(errMsg)

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
