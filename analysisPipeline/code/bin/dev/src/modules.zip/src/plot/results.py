#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import math

# # External imports
import holoviews as hv
import pandas as pd
from holoviews import opts
from holoviews.operation.datashader import datashade, dynspread
from holoviews.operation import decimate

# Internal imports
from .. import kmer
from ..ml.algorithm.constants import *
from .constants import *
from .common import HistogramFigure, ScatterFigure

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

class DistributionFigure(HistogramFigure):

    def __init__(self, meltedKmerFreq):

        """
        Args:
            meltedKmerFreq (pd.DataFrame):
                               id    filename kmer  proportion
                0  10:70096:80096  file_1.txt    A   31.686082
                1  10:70096:80096  file_2.txt    A   28.959431
                2  10:70096:80096  file_1.txt    C   18.313918
                3  10:70096:80096  file_2.txt    C   21.040569
        """

        HistogramFigure.__init__(self)

        self.meltedKmerFreq = meltedKmerFreq

    def createTable(self):
        pivotKmerFreq = kmer.rotate(self.meltedKmerFreq)
        return hv.Table(pivotKmerFreq)

    def getTableOpts(self):
        return [opts.Table(width=600)]

    def createBars(self):
        dataset = hv.Dataset(self.meltedKmerFreq, 
            kmer.KMER_COL_NAME, kmer.PERCENTAGE_COL_NAME)

        bars    = dataset.to(hv.Bars, 
            kmer.KMER_COL_NAME, kmer.PERCENTAGE_COL_NAME,
            groupby=[kmer.ID_COL_NAME, kmer.FILE_COL_NAME])

        nCols = int(math.sqrt(len(bars)))
        bars  = bars.layout().cols(nCols)
        return bars

    def getBarOpts(self):
        return [opts.Bars(tools=['hover'], width=400, height=400,
            xrotation=90, xlabel=kmer.KMER_COL_NAME, xticks=None,
            ylabel=kmer.PERCENTAGE_COL_NAME + " (%)")]

#------------------------------------------------------------#

class ClassificationFigure(ScatterFigure):

    def __init__(self, rPca, tPca):

        """
        Args:
            rPca / tPca (pd.DataFrame):
                               id    filename       PCA1       PCA2
                0  10:70096:80096  file_1.txt  -8.682768  -2.970983
                1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                        PCA3 [OPTIONAL]
                0  -2.970983
                1  -3.311564
        """

        ScatterFigure.__init__(self, N_PCA_COMPONENTS)

        self.rPcaDataset = hv.Dataset(rPca, PCA_DATA_COL_NAMES)
        self.tPcaDataset = hv.Dataset(tPca, PCA_DATA_COL_NAMES)

    def build(self):
        self.rScatter = self.createScatters(self.rPcaDataset)
        self.rScatter = self.rScatter.relabel(REF_LABEL).overlay()
        self.tScatter = self.createScatters(self.tPcaDataset)
        self.tScatter = self.tScatter.relabel(TARGET_LABEL).overlay()

    def style(self, vStyle=None):
        if (vStyle == 1):
            if (self.in2D):
                options = self.getScatterOpts() \
                    + [opts.Scatter(REF_LABEL, marker='s', size=7, alpha=0.4),
                       opts.Scatter(TARGET_LABEL, size=3, show_legend=False)]

            else:
                options = self.getScatterOpts() \
                    + [opts.Scatter3D(REF_LABEL, marker='square', size=3),
                       opts.Scatter3D(TARGET_LABEL, size=3, show_legend=False)]

            self.rScatter.opts(options)
            self.tScatter.opts(options)
            self.scatter = decimate(self.tScatter) * self.rScatter

        ## Scatter & Bivariate for visualising density
        elif(vStyle == 2):
            if (DLABEL_COL_NAME not in self.tPcaDataset.data.columns):
                raise KeyError("Requires density labels")

            if (self.in2D):
                self.rBivariate = self.rPcaDataset.to(hv.Bivariate,
                    PCA_DATA_COL_NAMES,
                    groupby=kmer.FILE_COL_NAME)
                self.rBivariate = self.rBivariate.overlay()


                options = self.getScatterOpts() \
                    + [opts.Scatter(REF_LABEL, marker='s', size=3, alpha=0.4),
                       opts.Scatter(TARGET_LABEL, size=7, cmap='Set1', alpha=0.2,
                           color=DLABEL_COL_NAME, show_legend=False),
                       opts.Bivariate(show_legend=False, filled=True)]
            else:
                raise NotImplementedError("3D not implemented.")

            tScatOver.opts(options)
            rScatOver.opts(options)
            rBiOver.opts(options)
            self.scatter = self.rBivariate * self.rScatter * decimate(self.tScatter)

        else:
            raise NotImplementedError("Unknown visual style.")

    def createScatters(self, pcaDataset):
        if (self.in2D):
            s = pcaDataset.to(hv.Scatter, PCA_DATA_COL_NAMES, 
                groupby=kmer.FILE_COL_NAME)
        else:
            s = pcaDataset.to(hv.Scatter3D, PCA_DATA_COL_NAMES, 
                groupby=kmer.FILE_COL_NAME)
        return s

#------------------------------------------------------------#

class PredictionFigure(ScatterFigure):

#     POSITIONS_ID_LENGTH = 8

    def __init__(self, pca):

        """
        Args:
            pca (pd.DataFrame):
                               id    filename       PCA1       PCA2
                0  10:70096:80096  file_1.txt  -8.682768  -2.970983
                1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                        PCA3 [OPTIONAL]
                0  -2.970983
                1  -3.311564
        """

        ScatterFigure.__init__(self, N_PCA_COMPONENTS)

        self.pcaDataset = hv.Dataset(pca, PCA_DATA_COL_NAMES)
        # tKmerPca      = self.addReadLabelColumn(tKmerPca)

    def build(self):
        self.scatter = self.createScatter()

    def style(self, vStyle=None):
        options = ScatterFigure.getScatterOpts(self)

        if (vStyle == 1):
            options = options \
                + [opts.Scatter(size=10)]
            self.scatter.opts(options)

        elif (vStyle == 2):
            self.scatter = datashade(self.scatter)
            self.scatter.opts(width=700, heigth=700)

        ## Scatter for visualising clusters
        elif (vStyle == 3):
            if (CLABEL_COL_NAME not in self.pcaDataset.data.columns):
                raise KeyError("Requires cluster labels")

            if (self.in2D):
                options = options \
                    + [opts.Scatter(size=7,
                           color=CLABEL_COL_NAME, cmap='Category10')]
            else:
                options = options \
                    + [opts.Scatter3D(size=7,
                           color=CLABEL_COL_NAME, cmap='Category10')]

            self.scatter.opts(options)

        ## Scatter & Bivariate for visualising density
        elif (vStyle == 4):
            if (DPROB_COL_NAME not in self.pcaDataset.data.columns):
                raise KeyError("Requires density labels")

            if (self.in2D):
                self.bivariate = self.pcaDataset.to(hv.Bivariate,
                    PCA_DATA_COL_NAMES)

                options = options \
                    + [opts.Bivariate(show_legend=False, filled=True),
                       opts.Scatter(size=TYPE_COL_NAME, alpha=0.2,
                           color=DPROB_COL_NAME, colorbar=True,
                           cmap='Inferno')]

            else:
                raise NotImplementedError("3D not implemented.")

            self.bivariate.opts(options)
            self.scatter.opts(options)
            self.scatter = self.bivariate * decimate(self.scatter)

        ## Scatter for visualising outliers
        elif (vStyle == 5):
            if (OLABEL_COL_NAME not in self.pcaDataset.data.columns):
                raise KeyError("Requires outlier labels")

            if (self.in2D):
                options = options \
                    + [opts.Scatter(size=7,
                           color=OLABEL_COL_NAME, cmap='Category10')]
            else:
                options = options \
                    + [opts.Scatter3D(size=7,
                           color=OLABEL_COL_NAME, cmap='Category10')]

            self.scatter.opts(options)

        else:
            raise NotImplementedError("Unknown visual style.")

    def createScatter(self):
        if (self.in2D):
            s = self.pcaDataset.to(hv.Scatter, PCA_DATA_COL_NAMES)
        else:
            s = self.pcaDataset.to(hv.Scatter3D, PCA_DATA_COL_NAMES)
        return s



#     def addReadLabelColumn(self, tKmerPca):
#         if (self.vStyle == 4):
#             positions = tKmerPca[ID_COL_NAME].str.split(':', expand=True)
#             if (len(positions.columns) == self.POSITIONS_ID_LENGTH):
#                 tKmerPca[TYPE_COL_NAME] = positions.apply(self.getReadLabel, axis=1)

#         return tKmerPca

#     def getReadLabel(self, row):

#         '''
#             s & t      |----------|==========|----------|
#             r                       |-----|
#             r                |-----|        |-----|
#             r            |-----|                |-----|
#         '''

#         sStart = int(row[1])
#         sEnd   = int(row[2])
#         tStart = int(row[4])
#         tEnd   = int(row[5])
#         rStart = int(row[6])
#         rEnd   = int(row[7])

#         isTarget  = (rStart >= tStart and rEnd <= tEnd)
#         isPartial = (tStart >= rStart and tStart <= rEnd) \
#                     or (tEnd >= rStart and tEnd <= rEnd)
#         isSource  = (not isTarget and not isPartial)

#         if (isTarget):
#             return 10

#         elif (isPartial):
#             return 10

#         else:
#             return 3

#         # ## Scatter plot (split)
#         # ## Colour by cluster and marker by data set
#         # ## Because clustering doesn't work well, we can ignore this step
#         # if (self.vStyle == 1):
#         #     pcaPoints  = self.splitDataset(self.pcaDataset)
#         #     overlays   = map(self.getOverlay1, pcaPoints)
#         #     options    = map(self.getStyleOptions1, pcaPoints)
#         #     self.plots = [x.opts(y) for x, y in zip(overlays, options)]

#         # def getOverlay1(self, pcaDataset):
#         #     scatters = self.getScatters(pcaDataset)
#         #     overlay  = scatters.overlay()
#         #     return overlay

#         # self.plots  = {idx : o for idx, o in enumerate(self.plots)}
#         # self.layout = hv.HoloMap(self.plots, kdims=['subset']).collate()

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
