#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os
import gzip

# External imports
import pandas as pd
from Bio import SeqIO

# Internal imports
from .constants import FASTA
from ..kmer.constants import ID_COL_NAME

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def readFastX(filepath):
    if (isZFile(filepath)):
        with gzip.open(filepath, 'rt') as filehandle:
            tmp       = os.path.splitext(filepath)[0]
            fastxType = getFastXType(tmp)
            seqRecs   = [seqRec.upper()
                         for seqRec in SeqIO.parse(filehandle, fastxType)]

    else:
        fastxType = getFastXType(filepath)
        seqRecs   = [seqRec.upper()
                     for seqRec in SeqIO.parse(filepath, fastxType)]

    return seqRecs

def readGFF(filepath):
    import gffutils             ## Requires python 3.5; not 3.7
    if (isZFile(filepath)):
        tmp = os.path.splitext(filepath)[0]
        if (isGFFFile(tmp)):
            featureDB = gffutils.create_db(filepath,
                ':memory:', force=True, keep_order=True,
                merge_strategy='merge', sort_attribute_values=True)

            featureDB.update(featureDB.create_introns())

    else:
        if (isGFFFile(filepath)):
            featureDB = gffutils.create_db(filepath,
                ':memory:', force=True, keep_order=True,
                merge_strategy='merge', sort_attribute_values=True)

            featureDB.update(featureDB.create_introns())

    return featureDB

def readKmerFrequencies(filepath):
    compression = 'gzip' if isZFile(filepath) else None
    kmerFreq    = pd.read_csv(filepath, sep='\t', compression=compression)

    if (isKmerFrequencyFile(kmerFreq)):
        return kmerFreq

#------------------- Private Classes & Functions ------------#

def isZFile(filepath):
    if (filepath.endswith('.gz') \
        or filepath.endswith('.gzip')):
        return True

    return False

def getFastXType(filepath):
    if (filepath.endswith('.fa') \
        or filepath.endswith('.fasta')):
        return FASTA

    elif (filepath.endswith('.fq') \
          or filepath.endswith('.fastq')):
        return 'fastq'

    else:
        raise NotImplementedError("Unknown fastX file")

def isGFFFile(filepath):
    if (filepath.endswith('.gff') \
        or filepath.endswith('.gff3')):
        return True

    else:
        raise NotImplementedError("Unknown GFF file")

    return False

def isKmerFrequencyFile(kmerFreq):
    if (ID_COL_NAME in kmerFreq.columns):
        if ((len(kmerFreq.columns) - 1) % 4 == 0):
            return True
        else:
            raise NotImplementedError("Unknown kmer frequency format")
    else:
        if (len(kmerFreq.columns) % 4 == 0):
            return True
        else:
            raise NotImplementedError("Unknown kmer frequency format")  

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
