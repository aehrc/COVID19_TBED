#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
from functools import reduce

# External imports
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import holoviews as hv
from holoviews import opts

# Internal imports
from . import core
from .constants import *
from ..util import spark

#------------------- Constants ------------------------------#

N_PCA_COMPONENTS = len(PCA_DATA_COLUMN_NAMES)

#------------------- Public Classes & Functions -------------#

def init(kmerFreqs, isRef=True):
    pipe = getPipeline()
    rPca = fit(pipe, kmerFreqs)

    if (isRef):
        rPca = core.formatTable(rPca, kmerFreqs, PCA_DATA_COLUMN_NAMES)

    return (pipe, rPca)

def transform(pipe, tKmerFreqs):
    with spark.getSparkContext() as sc:
        ## Data must fit in available memory!
        rdd = sc.parallelize(tKmerFreqs)
        rdd = rdd.cache()

        ## Get the PCAs for each record in parallel with Spark
        ## Result must fit in available memory!
        f     = lambda k: transformTarget(pipe, k)
        tPcas = rdd.map(f).collect()

    return tPcas

def getFigure(rKmerPca, tKmerPcas):

    '''
    Args:
        kmerFreq (pd.DataFrame):
                           id    filename       PCA1       PCA2
            0  10:70096:80096  file_1.txt  -8.682768  -2.970983
            1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                    PCA3 [OPTIONAL] cluster [OPTIONAL]
            0  -2.970983                3.0
            1  -3.311564                0.0
    Returns:
        figure (hv.Holomap/hv.NdLayout)
    '''

    ## Init plotting library (depending on 2D or 3D)
    core.initPlottingLibrary()

    rPcaDataset  = hv.Dataset(rKmerPca, PCA_DATA_COLUMN_NAMES)
    tPcaDatasets = [hv.Dataset(t, PCA_DATA_COLUMN_NAMES) for t in tKmerPcas]
    figure       = hv.HoloMap(kdims=[FILE_COL_NAME, 'subset'])

    ## Build figure
    for idx, tDataset in enumerate(tPcaDatasets):
        tPoints = core.splitPoints(tDataset)

        for jdx, tPoint in enumerate(tPoints):
            figure[(idx, jdx)] = buildOverlay(rPcaDataset, tPoint)

    ## [OPTIONAL] We can switch up the layout of the plots
    # figure = hv.NdLayout(figure).cols(len(tPcaDatasets))
    return figure

#------------------- Private Classes & Functions ------------#

def getPipeline():
    ## Set up PCA pipeline
    ## 1. Scale variables
    ## 2. Apply PCA
    pipe = Pipeline([('scaler', StandardScaler()),
                     ('reducer', PCA(n_components=N_PCA_COMPONENTS))])
    return pipe

def fit(pipe, kmerFreq):
    idx = kmerFreq.columns.get_loc(FILE_COL_NAME) + 1
    pca = pipe.fit_transform(kmerFreq.iloc[:, idx:])
    ## We are only explaining about 70% of the variance 
    ## with our PCA (not great, but works relatively OK)
    # print(pipe.steps[1][1].explained_variance_ratio_)
    return pca

def transformTarget(pipe, kmerFreq):
    idx = kmerFreq.columns.get_loc(FILE_COL_NAME) + 1
    pca = pipe.transform(kmerFreq.iloc[:, idx:])
    pca = core.formatTable(pca, kmerFreq, PCA_DATA_COLUMN_NAMES)
    return pca

def buildOverlay(rPcaDataset, tDataset):
    rScatters = core.buildScatters(rPcaDataset, REF_LABEL)
    tScatters = core.buildScatters(tDataset, TARGET_LABEL)
    scatters  = rScatters * tScatters

    ## Apply customisation to scatters
    scatters  = applyStyle(rPcaDataset, scatters)
    return scatters

def applyStyle(pcaDataset, scatters):
    if (core.is2D()):
        hover = core.getHoverTool()
        scatters.opts(
            opts.Scatter(tools=[hover], width=700, height=700),
            opts.Scatter(REF_LABEL, marker='s', size=15),
            opts.Scatter(TARGET_LABEL, size=7))

    else:
        scatters.opts(
            opts.Scatter3D(width=500, height=500),
            opts.Scatter3D(REF_LABEL, marker='square', size=15),
            opts.Scatter3D(TARGET_LABEL, size=7))
    return scatters
    
#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
