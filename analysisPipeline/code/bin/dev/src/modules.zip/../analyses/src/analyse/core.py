#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pandas as pd
from bokeh.models import HoverTool
import holoviews as hv
from holoviews import opts

# Internal imports
from .constants import *
from ..kmer.constants import ID_COL_NAME

#------------------- Constants ------------------------------#

## Maximum number of points that will be plotted
MAX_POINTS = 1000

#------------------- Public Classes & Functions -------------#

def formatTable(pcaArray, kmerFreq, columnNames):

    '''
    Args:
        pcaArray(np.ndarray):
            [[  -7.89444622 ... -20.82256807 ]
             [ -27.74461018 ...  23.5397721  ]
             [  22.02011738 ...   5.04338776 ]
                   ...          
             [  31.1867031  ...   4.94984223 ]
             [ -17.56776408 ... -12.71043402 ]]

        kmerFreq (pd.DataFrame):
               filename          A          C          G          T
            0  file.txt  31.686082  18.313918  18.313918  31.686082
        
        columnNames(List<String>):
            [column1, column2, column3]

    Returns:
        pcaTable(pd.DataFrame):
                  filename       PCA1       PCA2
            0   file_1.txt  -7.894446 -20.822568
            1   file_2.txt -27.744610  23.539772
    '''

    idx      = kmerFreq.columns.get_loc(FILE_COL_NAME) + 1
    pcaTable = pd.DataFrame(pcaArray, columns=columnNames)
    pcaTable = pd.concat([kmerFreq.iloc[:, :idx], pcaTable], axis=1)
    return pcaTable

def initPlottingLibrary():
    if (is2D()):
        hv.extension('bokeh')

    else:
        hv.extension('plotly')

def is2D():
    if (PCA3_COL_NAME not in PCA_DATA_COLUMN_NAMES):
        return True
    return False

def splitPoints(pcaCluster):
    for i in range(0, len(pcaCluster), MAX_POINTS):
        pcaPoints = pcaCluster.iloc[i:i + MAX_POINTS, :]
        yield pcaPoints

def buildScatters(pcaDataset, label):
    if (is2D()):
        scatters = pcaDataset.to(hv.Scatter, 
            PCA_DATA_COLUMN_NAMES, groupby=FILE_COL_NAME)
    else:
        scatters = pcaDataset.to(hv.Scatter3D, 
            PCA_DATA_COLUMN_NAMES, groupby=FILE_COL_NAME)

    scatters = scatters.relabel(label).overlay()
    return scatters

def getHoverTool():
    tooltips = [(PCA1_COL_NAME, '@PCA1'), 
                (PCA2_COL_NAME, '@PCA2'), 
                (FILE_COL_NAME, '@filename'),
                (ID_COL_NAME,   '@id')]

    hover = HoverTool(tooltips=tooltips)
    return hover

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
