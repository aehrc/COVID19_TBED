#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os

# External imports
from pyspark import SparkContext, SparkConf

# Internal imports

#------------------- Constants ------------------------------#

## Script constants (for Spark)
THIS_FILE = os.path.abspath(__file__)
THIS_DIR  = os.path.dirname(THIS_FILE)
SRC_DIR   = os.path.dirname(THIS_DIR)
SRC_ZIP   = os.path.join(SRC_DIR, "modules.zip")

#------------------- Public Classes & Functions -------------#

def getSparkContext():
    conf = SparkConf()
    conf.set('spark.local.dir', THIS_DIR)
    sc = SparkContext(pyFiles=[SRC_ZIP], conf=conf)
    ## Don't know/remember why my dependencies don't work
    ## But has something to do with the fact that the files aren't imported
    return sc

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------

