#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pandas as pd
import holoviews as hv
from holoviews import opts

# Internal imports
from ..analyse.constants import FILE_LABEL
from ..kmer.constants import *

#------------------- Constants ------------------------------#

## Set the plotting library
hv.extension('bokeh')

#------------------- Public Classes & Functions -------------#

def visualise(kmerFreq):

    ''''
    Args:
        kmerFreq (pd.DataFrame):
                 filename          A          C          G          T
            0  file_1.txt  31.686082  18.313918  18.313918  31.686082
            1  file_2.txt  28.959431  21.040569  21.040569  28.959431

    Returns:
        layout (hv.Layout)
    '''

    ## Reorganise kmerFreq into another format
    meltedKmerFreq = pd.melt(kmerFreq, id_vars=FILE_LABEL, 
        var_name=KMER_LABEL, value_name=PROPORTION_LABEL)

    figure = buildFigure(meltedKmerFreq)
    layout = hv.Layout(figure).cols(1)
    return layout

#------------------- Private Classes & Functions ------------#

def buildFigure(meltedKmerFreq):
    table  = buildTable(meltedKmerFreq)
    bars   = buildBars(meltedKmerFreq)
    figure = bars + table
    return figure

def buildTable(meltedKmerFreq):

    ''''
    Args:
        meltedKmerFreq (pd.DataFrame):
                 filename kmer  proportion
            0  file_1.txt    A   31.686082
            1  file_2.txt    A   28.959431
            2  file_1.txt    C   18.313918
            3  file_2.txt    C   21.040569

    Returns:
        table (hv.Table)
    '''

    pivotKmerFreq = meltedKmerFreq.pivot(index=KMER_LABEL, 
        columns=FILE_LABEL, values=PROPORTION_LABEL)
    pivotKmerFreq.reset_index(inplace=True)

    ## Create table and apply customisation
    table = hv.Table(pivotKmerFreq) \
              .opts(width=600)
    return table

def buildBars(meltedKmerFreq):

    ''''
    Args:
        meltedKmerFreq (pd.DataFrame):
                 filename kmer  proportion
            0  file_1.txt    A   31.686082
            1  file_2.txt    A   28.959431
            2  file_1.txt    C   18.313918
            3  file_2.txt    C   21.040569

    Returns:
        bars (hv.NdLayout)
    '''

    ## Create histograms
    dataset = hv.Dataset(meltedKmerFreq, KMER_LABEL, PROPORTION_LABEL)
    bars    = dataset.to(hv.Bars, KMER_LABEL, PROPORTION_LABEL, groupby=FILE_LABEL) \
                     .layout()

    ## Apply customisation to histograms
    barOpts = opts.Bars(tools=['hover'], width=400, height=400, 
                    xrotation=90, xlabel=KMER_LABEL, xticks=None,
                    ylabel=PROPORTION_LABEL + " (%)")
    bars.opts(barOpts)
    return bars

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
