#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pandas as pd
import holoviews as hv
from holoviews import opts

# Internal imports
from . import core
from ..analyse.constants import FILE_COL_NAME
from ..kmer.constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def getFigure(kmerFreq):

    ''''
    Args:
        kmerFreq (pd.DataFrame):
                 filename          A          C          G          T
            0  file_1.txt  31.686082  18.313918  18.313918  31.686082
            1  file_2.txt  28.959431  21.040569  21.040569  28.959431

    Returns:
        figure (hv.Holomap/hv.NdLayout)
    '''

    core.initPlottingLibrary()

    ## Reorganise kmerFreq into another format
    meltedKmerFreq = pd.melt(kmerFreq, id_vars=FILE_COL_NAME, 
        var_name=KMER_COL_NAME, value_name=PROPORTION_COL_NAME)

    table  = buildTable(meltedKmerFreq)
    bars   = buildBars(meltedKmerFreq)
    figure = (bars + table).cols(1)
    return figure

#------------------- Private Classes & Functions ------------#

def buildTable(meltedKmerFreq):

    ''''
    Args:
        meltedKmerFreq (pd.DataFrame):
                 filename kmer  proportion
            0  file_1.txt    A   31.686082
            1  file_2.txt    A   28.959431
            2  file_1.txt    C   18.313918
            3  file_2.txt    C   21.040569

    Returns:
        table (hv.Table)
    '''

    pivotKmerFreq = meltedKmerFreq.pivot(index=KMER_COL_NAME, 
        columns=FILE_COL_NAME, values=PROPORTION_COL_NAME)
    pivotKmerFreq.reset_index(inplace=True)

    ## Create table and apply customisation
    table = hv.Table(pivotKmerFreq) \
              .opts(width=600)
    return table

def buildBars(meltedKmerFreq):

    ''''
    Args:
        meltedKmerFreq (pd.DataFrame):
                 filename kmer  proportion
            0  file_1.txt    A   31.686082
            1  file_2.txt    A   28.959431
            2  file_1.txt    C   18.313918
            3  file_2.txt    C   21.040569

    Returns:
        bars (hv.NdLayout)
    '''

    ## Create histograms
    dataset = hv.Dataset(meltedKmerFreq, KMER_COL_NAME, PROPORTION_COL_NAME)
    bars    = dataset.to(hv.Bars, KMER_COL_NAME, PROPORTION_COL_NAME, groupby=FILE_COL_NAME) \
                     .layout().cols(2)

    ## Apply customisation to histograms
    barOpts = opts.Bars(tools=['hover'], width=400, height=400, 
                    xrotation=90, xlabel=KMER_COL_NAME, xticks=None,
                    ylabel=PROPORTION_COL_NAME + " (%)")
    bars.opts(barOpts)
    return bars

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
