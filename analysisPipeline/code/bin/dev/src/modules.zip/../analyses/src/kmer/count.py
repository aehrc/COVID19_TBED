#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import re
from itertools import product

# External imports
import pandas as pd

# Internal imports
from .constants import *

#------------------- Constants ------------------------------#

## Ensures that we don't have Kmers with N
NUCLEOTIDE_BASES = ['A', 'T', 'G', 'C']

#------------------- Public Classes & Functions -------------#

def getSequences(kmerLength):
    if (kmerLength <= 0):
        raise ValueError('Invalid kmer length')

    kmerSeqs = (''.join(c)
                for c in product(NUCLEOTIDE_BASES, repeat=kmerLength))
    return kmerSeqs

def getFrequenciesPerKmer(seqRecs, kmer):
    f = lambda x: getFrequencies(x, kmer)
    numKmers = sum(map(f, seqRecs))
    kmerFreq = pd.DataFrame([[kmer, numKmers]])
    return kmerFreq

def getFrequenciesPerRecord(seqRec, kmerSeqs):
    f = lambda x: getFrequencies(seqRec, x)
    kmerFreq = map(f, kmerSeqs)
    kmerFreq = {kmer:numKmers for kmer, numKmers in zip(kmerSeqs, kmerFreq)}
    kmerFreq = pd.DataFrame(list(kmerFreq.items()))
    kmerFreq.columns = [KMER_COL_NAME, FREQUENCY_COL_NAME]
    kmerFreq[ID_COL_NAME] = seqRec.id
    return kmerFreq

def getFrequencies(seqRec, kmer):
    ## We might not need to do the reverse complement.
    ## The reason being: the frequency of the reverse 
    ## complement is the same as the forward
    ## In other words:
    ##   Total Num(A)  = Num(A; Forward) + Num(A; Reverse)
    ## Num(A; Reverse) = Num(T; Forward)
    ## Therefore,
    ##   Total Num(A)  = Num(A; Forward) + Num(T; Forward)
    seqs = [seqRec.seq, seqRec.seq.reverse_complement()]
    f = lambda x: count(x, kmer)
    numKmers = sum(map(f, seqs))
    return numKmers

def calculateProportions(kmerFreq):
    ## Calculate the proportion for each Kmer
    kmerFreq[PROPORTION_COL_NAME] = \
        (kmerFreq[FREQUENCY_COL_NAME] / 
        kmerFreq[FREQUENCY_COL_NAME].sum()) * 100

    kmerFreq.fillna(0, inplace=True)
    return kmerFreq

#------------------- Private Classes & Functions ------------#

def count(seq, kmer):
    ## Count all overlapping occurrences of kmer
    pattern  = "(?=" + kmer + ")"
    numKmers = len(re.findall(pattern, str(seq)))
    return numKmers

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
