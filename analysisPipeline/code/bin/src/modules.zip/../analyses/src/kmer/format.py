#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os

# External imports
import pandas as pd

# Internal imports
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def formatFrequencies(kmerFreq):

    '''
    Args:
        kmerFreq (pd.DataFrame):
               kmer  frequency  proportion    id [OPTIONAL]
            0     A    2141798   30.872061  @M_1
            1     T    2141798   30.872061  @M_1
            2     G    1327031   19.127939  @M_1
            3     C    1327031   19.127939  @M_1

    Returns:
        kmerFreq (pd.DataFrame):
                 id [OPTIONAL]       A          C          G          T
            0  @M_1          30.872061  19.127939  19.127939  30.872061
    '''
    
    kmerFreq.drop(columns=[FREQUENCY_COL_NAME], inplace=True)

    if (ID_COL_NAME in kmerFreq.columns):
        kmerFreq = rotateFrequencies(kmerFreq)

    else:
        kmerFreq[ID_COL_NAME] = "tmp"
        kmerFreq = rotateFrequencies(kmerFreq)
        kmerFreq.drop(columns=[ID_COL_NAME], inplace=True)

    return kmerFreq

#------------------- Private Classes & Functions ------------#

def rotateFrequencies(kmerFreq):

    '''
    Args:
        kmerFreq (pd.DataFrame):
               kmer  proportion   id
            0     A   30.872061  @M1
            1     T   30.872061  @M1
            2     G   19.127939  @M1
            3     C   19.127939  @M1

    Returns:
        kmerFreq (pd.DataFrame):
               id           A          C          G          T
            0  @M1  30.872061  19.127939  19.127939  30.872061
    '''

    kmerFreq = kmerFreq.pivot(index=ID_COL_NAME, 
        columns=KMER_COL_NAME, values=PROPORTION_COL_NAME)
    kmerFreq.reset_index(inplace=True)

    ## Delete the column index name
    del kmerFreq.columns.name
    return kmerFreq

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
