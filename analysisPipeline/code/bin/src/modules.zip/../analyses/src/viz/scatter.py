#!/bin/python

#------------------- Description & Notes --------------------#

'''
FYI
layout.opts.info()
:Layout
    .Overlay.I :Overlay
        .NdOverlay.Ref    :NdOverlay   [filename]
            :Scatter   [PCA1,PCA2]   (filename)
            | Options(height=1000, marker='s', size=10, width=1000)
        .NdOverlay.Target :NdOverlay   [filename]
            :Scatter   [PCA1,PCA2]   (id,filename)
            | Options(height=1000, size=2, width=1000)
    .Table.I   :Table   [filename,PCA1,PCA2]
    | Options(width=5000)
    .Table.II  :Table   [id,filename,PCA1,PCA2]
    | Options(width=5000)
'''

#------------------- Dependencies ---------------------------#

# Standard library imports
import sys
from functools import reduce

# External imports
from bokeh.models import HoverTool
import holoviews as hv
from holoviews import opts, dim

# Internal imports
from ..analyse.constants import *
from ..kmer.constants import ID_LABEL
from ..analyse.cluster import CLUSTER_LABELS

#------------------- Constants ------------------------------#

## Set the plotting library
hv.extension('bokeh')

#------------------- Public Classes & Functions -------------#

def visualise(pca, withTable=False):

    ''''
    Args:
        kmerFreq (pd.DataFrame):
                           id    filename       PCA1       PCA2
            0  10:70096:80096  file_1.txt  -8.682768  -2.970983
            1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                    PCA3 [OPTIONAL] cluster [OPTIONAL]
            0  -2.970983                3.0
            1  -3.311564                0.0
    Returns:
        layout (hv.Layout)
    '''

    pcaDataset = buildDataset(pca)
    figure     = buildFigure(pcaDataset, withTable)
    layout     = hv.Layout(figure).cols(2)
    return layout

#------------------- Private Classes & Functions ------------#

def buildDataset(pca):
    dataColumnNames = DATA_COLUMN_NAMES_2D if is2D(pca) \
                      else DATA_COLUMN_NAMES_3D
    pcaDataset  = hv.Dataset(pca, dataColumnNames)
    return pcaDataset

def is2D(pca):
    if (PCA3_LABEL not in pca.columns):
        return True
    hv.extension('plotly')
    return False

def buildFigure(pcaDataset, withTable):
    holomap = buildHolomap(pcaDataset)
    return holomap

def buildHolomap(pcaDataset):
    holomap  = hv.HoloMap(kdims=[FILE_LABEL, 'subset'])

    isCluster = any(cLabel in pcaDataset.data.columns 
                    for cLabel in CLUSTER_LABELS)

    if (not isCluster):
        print("Building PCA overlay")
        overlay = buildNoClusteringOverlay(pcaDataset)

    else:
        print("Building Cluster overlay")

        f = lambda x: buildClusteringOverlay(pcaDataset, x)
        overlays = list(map(f, CLUSTER_LABELS))

        f = lambda x, y: x + y
        overlay = reduce(f, overlays)

    # ## Plots don't work properly. They require a web server
    # ## so that they can be interactive
    # # for i in range(0, len(tDataset.data)):
    # #     tPcaSubset = list(pca[i])

    # #     for j in range(0, len(tPcaSubset)):
    #         # tPcaChunk  = tPcaSubset[j]
    # overlay = build2DOverlay(rDataset, tDataset)

    holomap[(0, 0)] = overlay
    return holomap

def buildNoClusteringOverlay(pcaDataset):
    rDataset   = pcaDataset.select(type=REF_LABEL)
    tDataset   = pcaDataset.select(type=TARGET_LABEL)

    rScatters = buildScatters(rDataset, REF_LABEL)
    tScatters = buildScatters(tDataset, TARGET_LABEL)
    scatters  = rScatters * tScatters

    ## Apply customisation to scatters
    scatters  = applyNoClusteringStyle(pcaDataset, scatters)
    return scatters

def buildClusteringOverlay(pcaDataset, cLabel):
    scatters = buildScatters(pcaDataset, cLabel)

    ## Apply customisation to scatters
    scatters = applyClusteringStyle(pcaDataset, scatters, cLabel)
    return scatters

def buildScatters(pcaDataset, label):
    if (is2D(pcaDataset.data)):
        scatters = pcaDataset.to(hv.Scatter, 
            DATA_COLUMN_NAMES_2D, groupby=FILE_LABEL)
    else:
        scatters = pcaDataset.to(hv.Scatter3D, 
            DATA_COLUMN_NAMES_3D, groupby=FILE_LABEL)

    scatters = scatters.relabel(label).overlay()
    return scatters  

def applyNoClusteringStyle(pcaDataset, scatters):
    if (is2D(pcaDataset.data)):
        hover = buildHoverTool()
        scatters.opts(
            opts.Scatter(tools=[hover], width=1000, height=700),
            opts.Scatter(REF_LABEL, marker='s', size=15),
            opts.Scatter(TARGET_LABEL, size=7))

    else:
        scatters.opts(
            opts.Scatter3D(width=1000, height=700),
            opts.Scatter3D(REF_LABEL, marker='square', size=15),
            opts.Scatter3D(TARGET_LABEL, size=7))
    return scatters

def applyClusteringStyle(pcaDataset, scatters, cLabel):
    if (is2D(pcaDataset.data)):
        clusters     = pcaDataset.data[cLabel].unique().tolist()
        markers      = ['circle', 'triangle', 'square', 'diamond', 'asterisk']
        markerMapper = {c:m for c, m in zip(clusters, markers)}

        hover = buildHoverTool()
        scatters.opts(
            opts.Scatter(tools=[hover], show_legend=False,
                width=500, height=500),
            opts.Scatter(size=7,
                marker=dim(cLabel).categorize(markerMapper)))
    else:
        scatters.opts(
            opts.Scatter3D(width=500, height=500),
            opts.Scatter3D(size=7))
    return scatters

def buildHoverTool():
    tooltips = [(PCA1_LABEL, '@PCA1'), 
                (PCA2_LABEL, '@PCA2'), 
                (FILE_LABEL, '@filename'),
                (ID_LABEL,   '@id')]
    hover = HoverTool(tooltips=tooltips)
    return hover

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
