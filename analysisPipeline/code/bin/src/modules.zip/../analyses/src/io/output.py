#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import sys
import os

# External imports
from Bio import SeqIO
import holoviews as hv
import plotly

# Internal imports
from ..analyse import core

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def writeKmerFrequencies(filepath, kmerFreq):
    createDirIfNone(filepath)
    removeFileIfExists(filepath)
    kmerFreq.to_csv(filepath, 
        index=False, sep='\t')

def appendKmerFrequencies(filepath, kmerFreq):
    if (not os.path.exists(filepath)):
        writeKmerFrequencies(filepath, kmerFreq)
    else:
        kmerFreq.to_csv(filepath, header=False,
            index=False, sep='\t', mode='a')

def writeFastX(filepath, seqRecords, fastXtype):
    createDirIfNone(filepath)
    removeFileIfExists(filepath)
    SeqIO.write(seqRecords, filepath, fastXtype)

def writeFigure(filepath, figure):
    if (core.is2D()):
        hv.save(figure, filepath)

    else:
        # ## 3D plots can't be done with Bokeh
        # ## Must be done with either Matplotlib or Plotly

        # ## I don't know why hv.save doesn't work properly
        # hv.save(figure, filepath)

        ## Instead of holoviews, we have to rely on plotly for outputting
        ## 3D plots are nice but don't really work well
        ## https://github.com/pyviz/holoviews/issues/1819
        objstate = hv.renderer('plotly').get_plot(figure).state

        ## Manually customise the plot (via plotly)
        layoutDict = objstate['layout']
        layoutDict['width']  = 1500
        layoutDict['height'] = 1500

        ## Output plot
        plotly.offline.plot(objstate, filename=filepath)

#------------------- Private Classes & Functions ------------#

def createDirIfNone(filepath):
    try:
        ## Create DIR if it doesnt exist
        outputDir = os.path.dirname(filepath)
        if (not os.path.exists(outputDir)):
            os.makedirs(outputDir)
    except:
        pass

def removeFileIfExists(filepath):
    try:
        ## Ensure that we are always output 
        ## to a new file
        if (os.path.exists(filepath)):
            os.remove(filepath)
    except:
        print("Unknown exception. removeFileIfExists. TODO")
        sys.exit()

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
