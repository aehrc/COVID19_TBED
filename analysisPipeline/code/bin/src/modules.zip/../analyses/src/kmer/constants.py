#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports

# Internal imports

#------------------- Constants ------------------------------#

ID_COL_NAME         = 'id'
KMER_COL_NAME       = 'kmer'
FREQUENCY_COL_NAME  = 'frequency'
PROPORTION_COL_NAME = 'proportion'

#------------------- Public Classes & Functions -------------#

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
