#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
from functools import reduce

# External imports
import numpy as np
from sklearn.cluster import KMeans, \
    SpectralClustering, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
import holoviews as hv
from holoviews import opts, dim

# Internal imports
from . import core
from .constants import FILE_COL_NAME, PCA_DATA_COLUMN_NAMES

#------------------- Constants ------------------------------#

CLUSTER_LABELS = ['kmeans', 'spectral', 'averageAgg', 'wardAgg', 'gaussian']
N_CLUSTERS     = 3

#------------------- Public Classes & Functions -------------#

def transform(pca):
    f = lambda x: fit(pca, x)
    cLabels = list(map(f, getMethods()))

    pcaCluster = np.concatenate([pca] + cLabels, axis=1)
    return pcaCluster

def format(pcaCluster, kmerFreq):

    '''
    Args:
        pcaArray(np.ndarray):
            [[  -7.89444622 ... -20.82256807 ]
             [ -27.74461018 ...  23.5397721  ]
             [  22.02011738 ...   5.04338776 ]
                   ...          
             [  31.1867031  ...   4.94984223 ]
             [ -17.56776408 ... -12.71043402 ]]

        kmerFreq (pd.DataFrame):
               filename          A          C          G          T
            0  file.txt  31.686082  18.313918  18.313918  31.686082

    Returns:
        pcaTable(pd.DataFrame):
                  filename       PCA1       PCA2    cLabel1    cLabel2
            0   file_1.txt  -7.894446 -20.822568  -7.894446 -20.822568
            1   file_2.txt -27.744610  23.539772  -7.894446 -20.822568
    '''

    columnNames = PCA_DATA_COLUMN_NAMES + CLUSTER_LABELS
    pcaCluster  = core.formatTable(pcaCluster, kmerFreq, columnNames)
    [pcaCluster[cName].astype(str) for cName in CLUSTER_LABELS]
    return pcaCluster

def getFigure(pcaCluster, withTable=False):

    '''
    Args:
        kmerFreq (pd.DataFrame):
                           id    filename       PCA1       PCA2
            0  10:70096:80096  file_1.txt  -8.682768  -2.970983
            1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                    PCA3 [OPTIONAL] cluster [OPTIONAL]
            0  -2.970983                3.0
            1  -3.311564                0.0
    Returns:
        figure (hv.Holomap/hv.NdLayout)
    '''

    ## Init plotting library (depending on 2D or 3D)
    core.initPlottingLibrary()

    pcaDataset = hv.Dataset(pcaCluster, PCA_DATA_COLUMN_NAMES)

    ## Spark SHOULD work here. 
    ## But for some reason, collecting erases the styling....????
    pcaPoints = core.splitPoints(pcaDataset)
    layouts   = map(buildLayoutPerPoint, pcaPoints)
    layouts   = {idx : o for idx, o in enumerate(layouts)}
    figure    = hv.HoloMap(layouts, kdims=['subset']).collate().cols(2)
    return figure

#------------------- Private Classes & Functions ------------#

def getMethods():
    kMeans     = KMeans(n_clusters=N_CLUSTERS, random_state=0)
    spectral   = SpectralClustering(n_clusters=N_CLUSTERS, 
                     assign_labels='discretize')
    averageAgg = AgglomerativeClustering(n_clusters=N_CLUSTERS, 
                     linkage='average')
    wardAgg    = AgglomerativeClustering(n_clusters=N_CLUSTERS, 
                     linkage='ward')
    gaussian   = GaussianMixture(n_components=N_CLUSTERS, 
                     random_state=0)

    cAlgorithms = [kMeans, spectral, averageAgg, wardAgg, gaussian]
    return cAlgorithms

def fit(pca, cMethod):
    cLabel = cMethod.fit_predict(pca)
    cLabel = np.reshape(cLabel, (-1, 1))
    # print(cMethod.cluster_centers_)
    return cLabel

def buildLayoutPerPoint(pcaDataset):
    f = lambda x: buildOverlay(pcaDataset, x)
    overlays = map(f, CLUSTER_LABELS)

    ## Layout each overlay side-by-side
    f = lambda x, y: x + y
    layout = reduce(f, overlays)
    return layout

def buildOverlay(pcaDataset, cLabel):
    scatters = core.buildScatters(pcaDataset, cLabel)

    ## Apply customisation to scatters
    scatters = applyStyle(pcaDataset, scatters, cLabel)
    return scatters

def applyStyle(pcaDataset, scatters, cLabel):
    filenames    = pcaDataset.data[FILE_COL_NAME].unique().tolist()
    markers      = ['circle', 'square', 'diamond', 'x', 'cross']
    markerMapper = {c:m for c, m in zip(filenames, markers)}

    if (core.is2D()):
        hover = core.getHoverTool()
        scatters.opts(
            opts.Scatter(tools=[hover], show_legend=False,
                width=700, height=700, size=7,
                marker=dim(FILE_COL_NAME).categorize(markerMapper),
                color=cLabel, cmap='Category10'))
    else:
        scatters.opts(
            opts.Scatter3D(width=700, height=700, size=7,
                marker=dim(FILE_COL_NAME).categorize(markerMapper),
                color=cLabel, cmap='Category10'))
    return scatters

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
