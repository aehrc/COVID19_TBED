#!/bin/python

#------------------- Description & Notes --------------------#

'''
## Arguments
-f = FASTA files (.fa/.gz) / FASTQ files (.fa/.gz)
-g = GFF files (.gff)

-k = Kmer length
-w = Window size (bp)
-s = Step size (bp)
'''

#------------------- Dependencies ---------------------------#

# Standard library imports
import sys
import os
import argparse
from argparse import ArgumentParser, ArgumentTypeError

# External imports
import pandas as pd

# Internal imports

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

class ArgParser(ArgumentParser):

    def __init__(self):
        ArgumentParser.__init__(self)

    def error(self):
        self.print_help()
        sys.exit(2)

    def parse(self):
        pass

    def printArgs(self):
        args = self.parse_args()
        print(args)

    def isInt(self, value):
        try:
            intValue = int(value)
            return intValue

        except ArgumentTypeError as err:
            sys.exit(err)

    def isGTZeroInt(self, value):
        errMsg = "Invalid value. Must be > 0"
        try:
            intValue = self.isInt(value)
            if (intValue <= 0):
                raise ArgumentTypeError(errMsg)

        except ArgumentTypeError as err:
            sys.exit(err)

        return intValue

    def isGEZeroInt(self, value):
        errMsg = "Invalid value. Must be >= 0"
        try:
            intValue = self.isInt(value)
            if (intValue < 0):
                raise ArgumentTypeError(errorMsg)

        except ArgumentTypeError as err:
            sys.exit(err)

        return intValue

    def isFile(self, value):
        errMsg = "Invalid file"
        try:
            if (not os.path.exists(value) or os.path.isdir(value)):
                raise ArgumentTypeError(errMsg)

        except ArgumentTypeError as err:
            sys.exit(err)

        return value

#------------------------------------------------------------#

class CalculateKmerArgParser(ArgParser):

    def __init__(self):
        ArgParser.__init__(self)

        self.add_argument("-f", help="FASTA/FASTQ files (.fa/.fq)",
            nargs='+', type=self.isFile, required=True)
        self.add_argument("-k", help="Kmer length",
            nargs=1, type=self.isGTZeroInt, required=True)
        self.add_argument("-s", help="Split counts between IDs",
            action='store_true')
        self.add_argument("-o", help="Output file (.tsv)",
            nargs=1, required=True)

    def parse(self):
        try:
            args = self.parse_args()
    
            self.iFiles      = args.f
            self.kmerLength  = args.k[0]
            self.splitOutput = args.s
            self.oFile       = args.o[0]

        except (AttributeError, TypeError):
            self.error()

#------------------------------------------------------------#

class GenerateFastaArgParser(ArgParser):

    def __init__(self):
        ArgParser.__init__(self)

        ## Fixes an error that I really don't understand
        ## Related to the subclassing of ArgParser
        subparsers = self.add_subparsers(dest='command')
        subparsers._parser_class = ArgumentParser

        ## Create a subparsers
        self.createChromosomeSubparser(subparsers)
        self.createFeatureSubparser(subparsers)

    def createChromosomeSubparser(self, subparsers):
        p = subparsers.add_parser('position')
        p.add_argument("-w", help="Window size (bp)",
            nargs=1, type=self.isGTZeroInt, required=True)
        p.add_argument("-i", help="ID \
            (Must match an ID in the FASTA files)",
            nargs='?')
        self.initArgs(p)

    def createFeatureSubparser(self, subparsers):
        p = subparsers.add_parser('feature')
        p.add_argument("-g", help="Genome annotation file (.gff)",
            nargs=1, type=self.isFile, required=True)
        p.add_argument("-i", help="ID \
            (Must match a feature type in the GFF file)",
            nargs='?')
        self.initArgs(p)

    def initArgs(self, p):
        p.add_argument("-f", help="FASTA files (.fa/.gz)",
            nargs='+', type=self.isFile, required=True)
        p.add_argument("-o", help="Output file (.fa)", 
            nargs=1, required=True)
        p.add_argument("-n", help="Number of FASTA files \
            (Uses random sequence positions)",
            nargs=1, type=self.isGTZeroInt, required=True)

    def parse(self):
        try:
            args = self.parse_args()

            self.command  = args.command
            self.iFiles   = args.f
            self.oFile    = args.o[0]
            self.numFasta = args.n[0]

        except AttributeError:
            self.error()

    def parseChromosomeArgs(self):
        args = self.parse_args()

        self.windowSize = args.w[0]
        self.fastaId    = None if args.i is None else args.i

    def parseFeatureArgs(self):
        args = self.parse_args()

        self.annoFile  = args.g[0]
        self.featureId = None if args.i is None else args.i

#------------------------------------------------------------#

class SequentialKmerArgParser(ArgParser):

    def __init__(self):
        ArgParser.__init__(self)

        self.add_argument("-f", help="FASTA files (.fa/.gz)",
            nargs='+', type=self.isFile, required=True)
        self.add_argument("-i", help="ID \
            (Must match an ID in the FASTA files)",
            nargs=1, required=True)
        self.add_argument("-w", help="Window size (bp)",
            nargs=1, type=self.isGTZeroInt, required=True)
        self.add_argument("-s", help="Step size (bp)",
            nargs=1, type=self.isGTZeroInt, required=True)
        self.add_argument("-k", help="Kmer length",
            nargs=1, type=self.isGTZeroInt, required=True)
        self.add_argument("-o", help="Output file (.tsv)",
            nargs=1, required=True)

    def parse(self):
        try:
            args = self.parse_args()

            self.iFiles     = args.f
            self.fastaId    = args.i[0]
            self.windowSize = args.w[0]
            self.stepSize   = args.s[0]
            self.kmerLength = args.k[0]
            self.oFile      = args.o[0]
   
        except AttributeError:
            self.error()

#------------------------------------------------------------#

class AnalyseKmerArgParser(ArgParser):

    def __init__(self):
        ArgParser.__init__(self)

        ## Fixes an error that I really don't understand
        ## Related to the subclassing of ArgParser
        subparsers = self.add_subparsers(dest='command')
        subparsers._parser_class = ArgumentParser

        ## Create subparsers 
        self.createHistogramSubparser(subparsers)
        self.createPcaSubparser(subparsers)
        self.createClusterSubparser(subparsers)

    def createHistogramSubparser(self, subparsers):
        p = subparsers.add_parser('histogram')
        p.add_argument("-i", help="Kmer frequency files (.tsv)",
            nargs='+', type=self.isFile, required=True)
        self.initArgs(p)

    def createPcaSubparser(self, subparsers):
        p = subparsers.add_parser('pca')
        p.add_argument("-r", help="Reference Kmer frequency files (.tsv)",
            nargs='+', type=self.isFile, required=True)
        p.add_argument("-t", help="Target Kmer frequency file (.tsv)",
            nargs='+', type=self.isFile, required=True)
        p.add_argument("-a", help="Output table",
            action='store_true')
        self.initArgs(p)

    def createClusterSubparser(self, subparsers):
        p = subparsers.add_parser('cluster')
        p.add_argument("-i", help="Kmer frequency files (.tsv)",
            nargs='+', type=self.isFile, required=True)
        self.initArgs(p)

    def initArgs(self, p):
        p.add_argument("-o", help="Output file (.html)",
            nargs=1, required=True)

    def parse(self):
        try:
            args = self.parse_args()

            self.command = args.command
            self.oFile   = args.o[0]
   
        except AttributeError:
            self.error()

    def parseHistogramArgs(self):
        args = self.parse_args()

        self.iFiles = args.i

    def parsePcaArgs(self):
        args = self.parse_args()

        self.rFiles = args.r
        self.tFiles = args.t

    def parseClusterArgs(self):
        args = self.parse_args()

        self.iFiles = args.i

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------

