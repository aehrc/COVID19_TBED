#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import random
import re
from functools import reduce

# External imports
from Bio.SeqRecord import SeqRecord

# Internal imports

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def getFaRecord(fastaId, faRecs):
    if (fastaId is not None):
        f        = lambda x: x.id == fastaId
        faRec = list(filter(f, faRecs))

    else:
        ## Choose a random chromosome
        randFaIdx = random.randint(0, len(faRecs) - 1)

        ## Choose a random position in the chromosome
        ## We only look at the forward strand positions
        faRec = [faRecs[randFaIdx]]

    return faRec

def getFeatureRecord(featureId, featureDB):
    features = []

    if (featureId is not None):
        features = list(featureDB.features_of_type(featureId))

    else:
        ## We want regions that are entirely non-coding
        ## i.e., intergenic, telomeres, centromere
        features = list(featureDB.features_of_type('inter_gene_gene'))

        ## If we have already calculated interfeatures,
        ## then we shouldn't do it again
        if (len(features) == 0):
            featureDB = addInterfeatures(featureDB)
            features  = list(featureDB.features_of_type('inter_gene_gene'))

    randFeatureIdx = random.randint(0, len(features) - 1)
    randFeatureRec = features[randFeatureIdx]
    return randFeatureRec

def getRandomIntervalSeqRecord(faRec, windowSize):
    seq  = ""

    ## Get a random sequence that doesn't contain N's
    while (len(seq) == 0 or seq.count("N") != 0):
        idx          = len(faRec.seq) - windowSize - 1
        randStartPos = random.randint(0, idx)
        endPos       = randStartPos + windowSize
        seq          = faRec.seq[randStartPos:endPos]

    seqRec = createSeqRecord(faRec, randStartPos, endPos, seq)
    return seqRec

def getFeatureSeqRecord(faRec, featureRec):
    if ('Name' not in featureRec.attributes):
        raise NotImplementedError('No name detected')

    fId      = featureRec.attributes['Name'][0]
    fType    = featureRec.featuretype
    startPos = featureRec.start
    endPos   = featureRec.stop
    strand   = featureRec.strand

    seq    = faRec.seq[startPos:endPos]
    seq    = seq.reverse_complement() if (strand == '-') else seq
    fInfo  = (fType, fId)
    seqRec = createSeqRecord(faRec, startPos, endPos, seq, fInfo)
    return seqRec

def createSeqRecord(faRec, startPos, endPos, seq, fInfo=None):
    if (fInfo is not None):
        fType = fInfo[0]
        fId   = fInfo[1]
        seqId = "{id}:{fType}:{fId}:{startPos}:{endPos}".format(
                    id=faRec.id, fId=fId, fType=fType, 
                    startPos=startPos, endPos=endPos)

    else:
        seqId  = "{id}:{startPos}:{endPos}".format(id=faRec.id,
                    startPos=startPos, endPos=endPos)

    seqRec = SeqRecord(seq, id=seqId, description=faRec.description)
    return seqRec

#------------------- Private Classes & Functions ------------#

def addInterfeatures(featureDB):
    ## GFFutils featureDB.interfeatures() does not work when 
    ## there are features from different chromosomes or strand
    seqIdList  = getSeqIds(featureDB)
    strandList = getStrands(featureDB)
    features   = list(featureDB.features_of_type('gene'))

    ## There is an issue in that we are only looking at regions
    ## between gene features. Such regions MAY or MAY NOT contain
    ## features (i.e., non-coding exons, tRNAs etc...).
    ## In these cases, we need to either remove or shorten each feature
    for s in strandList:
        for seqId in seqIdList:
            f = lambda x: x.strand == s and x.seqid == seqId
            featuresSublist = filter(f, features)
            interfeatures   = featureDB.interfeatures(featuresSublist)
            interfeatures   = map(updateInterfeatureName, interfeatures)
            featureDB.update(interfeatures)

    return featureDB

def getSeqIds(featureDB):
    seqIdQuery  = 'SELECT DISTINCT seqid FROM features;'
    seqIdResult = featureDB.execute(seqIdQuery)

    f = lambda x, y: list(x) + list(y)
    seqIdList = list(reduce(f, seqIdResult))
    return seqIdList

def getStrands(featureDB):
    strandQuery  = 'SELECT DISTINCT strand FROM features \
                    WHERE strand != ".";'   ## Some features don't have a strand
    strandResult = featureDB.execute(strandQuery)

    f = lambda x, y: list(x) + list(y)
    strandList = list(reduce(f, strandResult))
    return strandList

def updateInterfeatureName(interfeature):
    f = lambda x: re.sub('^.*:', '', x)
    names = list(map(f, interfeature.attributes['ID']))

    name  = ['_'.join(names)]
    interfeature.attributes['Name'] = name
    return interfeature

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
