#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os

# External imports

# Internal imports

#------------------- Constants ------------------------------#

THIS_FILE = os.path.abspath(__file__)
# THIS_DIR  = os.path.dirname(THIS_FILE)
# SRC_DIR   = os.path.dirname(THIS_DIR)
# SRC_ZIP   = os.path.join(SRC_DIR, "modules.zip")

#------------------- Public Classes & Functions -------------#

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
