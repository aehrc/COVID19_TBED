#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import math

# External imports
from bokeh.models import HoverTool
import datashader as ds
import holoviews as hv
from holoviews import opts
from holoviews.operation.datashader import datashade, dynspread
from holoviews.operation import decimate
import pandas as pd

# Internal imports
from .constants import *
from ..ml.algorithm.constants import *
from ..kmer.constants import *
from ..util import spark

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

class Figure():

    def __init__(self):
        self.layout = None

    def build(self):
        pass

    def style(self, vStyle=None):
        pass

    def assemble(self):
        pass

#------------------------------------------------------------#

class HistogramFigure(Figure):

    def __init__(self):
        Figure.__init__(self)
        hv.extension('bokeh')

    def build(self):
        self.table = self.createTable()
        self.bars  = self.createBars()

    def style(self, vStyle=None):
        self.table.opts(self.getTableOpts())
        self.bars.opts(self.getBarOpts())

    def assemble(self):
        self.layout = (self.bars + self.table)
        self.layout = self.layout.cols(1)

#------------------------------------------------------------#

class ScatterFigure(Figure):

    def __init__(self, nCols):
        Figure.__init__(self)

        self.in2D = True if nCols == 2 else False
        self.initPlottingLibrary()

    def initPlottingLibrary(self):
        if (self.in2D):
            hv.extension('bokeh')

        else:
            hv.extension('plotly')

    def assemble(self):
        self.layout = self.scatter

    # def assemble(self):
    #     # self.layout = hv.HoloMap(self.plots, kdims=['subset'])

    #     # ## [OPTIONAL] We can switch up the layout of the plots
    #     # ## Cannot use holomap for 3D output
    #     # nCols       = int(math.sqrt(len(self.layout)))
    #     # self.layout = hv.NdLayout(self.layout).cols(nCols)

    def getScatterOpts(self):
        if (self.in2D):
            o = [opts.Scatter(tools=['hover'], width=700, height=700)]
        else:
            o = [opts.Scatter3D(width=700, height=700)]
        return o

#     ## Maximum number of points that will be plotted
#     MAX_POINTS = 1000

#     def getDefaultOptions(self):
#         if (self.is2D()):
#             options = [opts.Scatter(tools=['hover'], width=700, height=700),
#                        opts.Bivariate(tools=['hover'], width=700, height=700),
#                        opts.HexTiles(tools=['hover'], width=700, height=700),
#                        opts.Image(tools=['hover'], width=700, height=700)]
#         else:
#             options = [opts.Scatter3D(width=700, height=700)]

#         return options

#     def splitDataset(self, pcaDataset):
#         for i in range(0, len(pcaDataset), self.MAX_POINTS):
#             pcaPoints = pcaDataset.iloc[i:i + self.MAX_POINTS, :]
#             yield pcaPoints


#     def getHexTiles(self, pcaDataset):
#         if (self.is2D()):
#             hextiles = pcaDataset.to(hv.HexTiles,
#                 PCA_DATA_COL_NAMES, groupby=FILE_COL_NAME)

#         else:
#             raise NotImplementedError("3D HexTiles not implemented.")

#         return hextiles

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
