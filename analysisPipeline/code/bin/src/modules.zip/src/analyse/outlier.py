#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import numpy as np
from sklearn.neighbors import LocalOutlierFactor

# Internal imports
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(pca):
    print("Running outlier detection")
    lof     = LocalOutlierFactor()
    oLabels = lof.fit_predict(pca)
    oLabels = np.reshape(oLabels, (-1, 1))
    return oLabels

#------------------- Private Classes & Functions ------------#



#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
