#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports

# Internal imports

#------------------- Constants ------------------------------#

''' PCA related constants '''
PCA1_COL_NAME   = 'PCA1'
PCA2_COL_NAME   = 'PCA2'
PCA3_COL_NAME   = 'PCA3'

## Data column names
DATA_COL_NAMES_2D = [PCA1_COL_NAME, PCA2_COL_NAME]
DATA_COL_NAMES_3D = [PCA1_COL_NAME, PCA2_COL_NAME, PCA3_COL_NAME]

## [OPTIONAL] Update to DATA_COL_NAMES_3D for 3D PCA
PCA_DATA_COL_NAMES = DATA_COL_NAMES_2D
N_PCA_COMPONENTS   = len(PCA_DATA_COL_NAMES)

''' Clustering related constants '''
CLUSTER_COL_NAME   = 'cLabel'
NCLUSTERS_COL_NAME = 'nClusters'
BIC_COL_NAME       = 'BIC'
AIC_COL_NAME       = 'AIC'

''' Density related constants '''
DENSITY_PROB_COL_NAME  = 'dProb'
DENSITY_LABEL_COL_NAME = 'dLabel'

''' Outlier related constants '''
OUTLIER_COL_NAME = 'oLabel'

#------------------- Public Classes & Functions -------------#

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
