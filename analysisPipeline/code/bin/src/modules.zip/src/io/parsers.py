#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import os
import re
import gzip

# External imports
import pandas as pd
from Bio import SeqIO

# Internal imports
from .constants import *
from ..kmer.constants import ID_COL_NAME
from ..kmer.table import addFileColumn

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def readFastX(filepath):

    """
    Description:
        Reads a FASTX file and generates a list of sequence records.

    Args:
        filepath (str):
            Filepath string.

    Returns:
        seqRecs (list<Bio.SeqRecord.SeqRecord>):
            List of sequence records.
    """

    if (isZFile(filepath)):
        with gzip.open(filepath, 'rt') as filehandle:
            tmp       = os.path.splitext(filepath)[0]
            fastxType = getFastXType(tmp)
            seqRecs   = [seqRec.upper()
                         for seqRec in SeqIO.parse(filehandle, fastxType)]

            ## Ensembl .fa.gz files contain both
            ## chromosome and scaffold / haplotype sequences
            ## Probably better to ignore scaffold / haplotyle sequences
            ## If we want to consider them, just remove the condition
            if (fastxType == FASTA):
                seqRecs = filterFasta(seqRecs)

    else:
        fastxType = getFastXType(filepath)
        seqRecs   = [seqRec.upper()
                     for seqRec in SeqIO.parse(filepath, fastxType)]

    return seqRecs

def readGFF(filepath):
    import gffutils             ## Requires python 3.5; not 3.7
    if (isZFile(filepath)):
        tmp = os.path.splitext(filepath)[0]
        if (isGFFFile(tmp)):
            featureDB = gffutils.create_db(filepath,
                ':memory:', force=True, keep_order=True,
                merge_strategy='merge', sort_attribute_values=True)

            featureDB.update(featureDB.create_introns())

    else:
        if (isGFFFile(filepath)):
            featureDB = gffutils.create_db(filepath,
                ':memory:', force=True, keep_order=True,
                merge_strategy='merge', sort_attribute_values=True)

            featureDB.update(featureDB.create_introns())

    return featureDB

def readKmerFrequencies(filepath, chunksize=None):

    """
    Description:
        Reads a KmerFreq file and generates a table containing 
        the counts of every kmer sequence.

    Args:
        filepath (str):
            Filepath string.

        chunksize (int; Optional)
            If specified, split the file into smaller chunks of a given size.
            If None, do not split the file into smaller chunks.

    Returns:
        kmerFreqs (list<pd.DataFrame>):
            List of dataframes containing the counts of every kmer sequence.
    """

    compression = 'gzip' if isZFile(filepath) else None
    kmerFreqs   = list(pd.read_csv(filepath, sep='\t', compression=compression,
        chunksize=chunksize, iterator=True))

    for k in kmerFreqs:
        if (isKmerFrequencyFile(k)):
            k = addFileColumn(k, filepath)

    return kmerFreqs

def readTable(filepath):
    compression = 'gzip' if isZFile(filepath) else None
    t           = pd.read_csv(filepath, sep='\t', compression=compression)
    return t

#------------------- Private Classes & Functions ------------#

def isZFile(filepath):
    if (filepath.endswith('.gz') \
        or filepath.endswith('.gzip')):
        return True

    return False

def getFastXType(filepath):
    if (filepath.endswith('.fa') \
        or filepath.endswith('.fasta')):
        return FASTA

    elif (filepath.endswith('.fq') \
          or filepath.endswith('.fastq')):
        return FASTQ

    else:
        raise NotImplementedError("Unknown fastX file")

def filterFasta(seqRecs):
    f = lambda x: re.search(" REF$", x.description) \
              and re.search(":chromosome chromosome:", x.description)
    newSeqRecs = list(filter(f, seqRecs))
    return newSeqRecs

def isGFFFile(filepath):
    if (filepath.endswith('.gff') \
        or filepath.endswith('.gff3')):
        return True

    else:
        raise NotImplementedError("Unknown GFF file")

    return False

def isKmerFrequencyFile(kmerFreq):
    nCol = len(kmerFreq.columns)
    nCol = nCol - 1 if (ID_COL_NAME in kmerFreq.columns) else nCol

    if (nCol % 4 == 0):
        return True

    else:
        raise NotImplementedError("Unknown kmer frequency format")

    return False

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
