#!/bin/python

#------------------- Description & Notes --------------------#

'''
Kmer frequencies only need to be calculated in
the forward or reverse direction. We don't need to
do both, since they basically contain the same information.
In fact, the forward proportion is roughly equivalent to the
forward & reverse proportion

Numerical approach of current implementation (getCountsByLength)
It involves bit shifting (Slightly faster?)
def countByKmerLength(seq, kmerLength):
    maxKmerSeqIdx  = getExpectedTotal(kmerLength) - 1
    maxKmerSeqMask = np.uint64(maxKmerSeqIdx)  
    bStr           = np.uint64(0)
    cLen           = 0
    numKmers       = defaultdict(int)

    for c in seq:
        cVal = NUCLEOTIDES[c] if c in NUCLEOTIDES else 4
        bVal = np.uint64(cVal)

        if (cVal < 4):
            bStr = bStr + bVal
            cLen = cLen + 1

            if (cLen >= kmerLength):
                numKmers[bStr&maxKmerSeqMask] += 1

            bStr = bStr << np.uint64(2)

        elif (cVal == 4):
            cLen = 0

    return numKmers
'''

#------------------- Dependencies ---------------------------#

# Standard library imports
import re
import math
from operator import add
from collections import Counter

# External imports
import pandas as pd
import numpy as np

# Internal imports
from .constants import *
from .common import getExpectedSequences
from .common import getExpectedTotal
from ..util import spark

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def getCombinedCounts(rdd, kmerLength):
    ## Get the kmer counts across all records
    ## Counts are (K, V) pairs, where K = sequence and V = frequency
    ## **********
    ## *** This is (probably) the "best" approach for combined counts.
    ## *** RDD ReduceBy runs better than DataFrame GroupBy.
    ## *** So DO NOT change!!!
    ## ***
    ## *** Using RDD ReduceBy once to minimise shuffling seems to encounter
    ## *** a few errors (not sure why). Might have to revert to the 
    ## *** RDD ReduceBy and DataFrame GroupBy combination implementation
    ## *** 
    ## *** My understanding is that DataFrames GroupBy is faster, but
    ## *** I don't understand why this isn't the case. I've tried
    ## ***  * Explicitly defining the schema
    ## ***  * Repartitioning the DataFrame before grouping
    ## *** 
    ## *** I'm also encountering BlockManager warnings with the DataFrame
    ## *** implementation (I'm not sure if they are significant)
    ## *** and Java Exceptions (which terminates the program...)
    ## **********
    ## (ID, Seq) => (ID, kmerSeq)
    ##           => (ID, kmerSeq, 1)
    f = lambda x: getObservedSequences(x, kmerLength)
    kmerRdd = rdd.flatMapValues(f) \
                 .map(lambda x: (0, x[1], 1))
    return kmerRdd

def getSplitCounts(rdd, kmerLength):
    ## Get the kmer counts for each record
    ## Counts are (K, V) pairs, where K = sequence and V = frequency
    ## **********
    ## *** Not sure if this is really the best approach for split counts.
    ## *** RDD ReduceByKey runs (a bit) better than DataFrame GroupBy.
    ## ***
    ## *** To improve efficiency, I've tried:
    ## ***  * Using fewer lambda functions to reduce double serialisation.
    ## ***  * Repartitioning before reducing, which doesn't seem to give 
    ## ***    any major improvements since we would be shuffling twice.
    ## **********
    ## (ID, Seq) => ((ID, total), Seq)
    ##           => ((ID, total), kmerSeq)
    ##           => ((ID, total, kmerSeq), 1)
    ##           => ((ID, total, kmerSeq), count)
    ##           => (ID, total, kmerSeq, count)
    # nParts = math.floor((rdd.getNumPartitions() / 2) * spark.N_PARTS_MULTI)
    # f = lambda x: ((x[0], getObservedTotal(x[1], kmerLength)), x[1])
    # g = lambda x: getObservedSequences(x, kmerLength)
    # kmerRdd = rdd.map(f).flatMapValues(g) \
    #              .map(lambda x: ((*x[0], x[1]), 1)) \
    #              .reduceByKey(add, nParts) \
    #              .map(lambda x: (x[0][0], x[0][1], x[0][2], x[1]))

    ##  ********** APPROACH 2
    ##  *** The problem I have is with the totals
    ##  *** I suspect we should be using another table or RDD
    ##  *** And then just looking up the value
    ##  *** I just don't know how or whether thats a good idea or not
    ## (ID, Seq) => (ID, kmerSeq)
    ##           => ((ID, kmerSeq), 1)
    f = lambda x: getObservedSequences(x, kmerLength)
    kmerRdd = rdd.flatMapValues(f) \
                 .map(lambda x: (x, 1))
    kmerRdd.cache()

    ## Insert rows for kmer sequences with zero counts into the table
    ## ONLY IF we know we have to
    zeroRdd      = getZeroCounts(rdd, kmerLength)
    observedSeqs = kmerRdd.distinct().count()
    expectedSeqs = (rdd.count() * getExpectedTotal(kmerLength))
    if (observedSeqs < expectedSeqs):
        zeroRdd = zeroRdd.map(lambda x: (x[:2], x[2]))
        kmerRdd = kmerRdd.union(zeroRdd)

    ## Minimise shuffling by reducing it all at once
    ## ((ID, kmerSeq), 1) => ((ID, kmerSeq), count)
    ##                    => (ID, kmerSeq, count)
    nParts  = math.floor((rdd.getNumPartitions() / 2) * spark.N_PARTS_MULTI)
    kmerRdd = kmerRdd.reduceByKey(add, nParts) \
                     .map(lambda x: (x[0][0], x[0][1], x[1]))

    kmerRdd.toDF().show()
    return kmerRdd

def getZeroCounts(rdd, kmerLength):
    ## (ID, Seq) => (ID, kmerSeq)
    ##           => (ID, kmerSeq, 0)
    kmerSeqs = list(getExpectedSequences(kmerLength))
    zeroRdd = rdd.flatMapValues(lambda x: kmerSeqs) \
                  .map(lambda x: (*x, 0))
    return zeroRdd

def getTotalCounts(rdd, kmerLength):
    ## Get the total number of kmers across all records
    ## (ID, Seq) => (ID, total)
    f = lambda x: getObservedTotal(x, kmerLength)
    totalRdd = rdd.mapValues(f)
    return totalRdd

#------------------- Private Classes & Functions ------------#

def getObservedSequences(seq, kmerLength):

    """
    Description:
        Generates a list of kmer sequences of length K in a sequence.

    Args:
        seq (str):
            Sequence to be examined.

        kmerLength (int):
            Length of kmers. Must be a positive integer.

    Returns:
        kmerSeqs (list):
            List of str containing the kmer sequences of length K
            in the sequence record
    """

    totalKmers = getObservedTotal(seq, kmerLength)
    return [seq[i:i + kmerLength] for i in range(0, totalKmers)]

def getObservedTotal(seq, kmerLength):
    return len(seq) - kmerLength + 1

#------------------- Unused Classes & Functions ------------#

def _getCounts(kmerSeqs):

    """
    Description:
        Count how often kmer sequences of length K occur.

    Args:
        kmerSeqs (list):
            List of kmer sequences.

        kmerLength (int):
            Length of kmers. Must be a positive integer.

    Returns:
        kmerPairs (list):
            List of tuples containing the counts of every 
            kmer sequence of length K. Tuples are (K, V) pairs
            where K = kmer sequence, and V = frequency.
    """

    kmerPairs = Counter(kmerSeqs)
    return list(kmerPairs.items())

def _getCountsByLength(seq, kmerLength):

    """
    Description:
        Generates a list of tuples containing the counts of
        every kmer sequence of length K in a sequence.

    Args:
        seq (str):
            Sequence to be examined.

        kmerLength (int):
            Length of kmers. Must be a positive integer.

    Returns:
        kmerPairs (list):
            List of tuples containing the counts of every 
            kmer sequence of length K in the sequence record. Tuples 
            are (K, V) pairs where K = kmer sequence, and V = frequency.
    """

    kmerSeqs  = getObservedSequences(seq, kmerLength)
    kmerPairs = getCounts(kmerSeqs)
    return list(kmerPairs.items())

def _getCountsBySequences(seq, kmerSeqs):

    """
    Description:
        Generates a list of tuples containing the counts of
        possible kmer sequence in a sequence.

    Args:
        seq (str):
            Sequence to be examined.

        kmerSeqs (list):
            List of all possible kmer sequences.

    Returns:
        kmerPairs (list):
            List of tuples containing the counts of every 
            kmer sequence of length K. Tuples are (K, V) pairs
            where K = kmer sequence, and V = frequency.
    """

    ## Pattern for counting all overlapping occurrences
    f = lambda x: getCountsBySequence(seq, x)
    kmerPairs = map(f, kmerSeqs)
    return list(kmerPairs)

def getCountsBySequence(seq, kmerSeq):
    p = "(?=" + kmerSeq + ")"
    c = len(re.findall(p, seq))
    return (kmerSeq, c)

def _isValidPair(kmerPair):

    """
    Description:
        Checks whether the kmer sequence contains unexpected characters.

    Args:
        kmerPair (tuple):
            (K, V) pair tuple, where K = kmer sequence and V = frequency.

    Returns:
        True if the kmer sequence does not contain unexpected characters
        False if the kmer sequence contains unexpected characters (i.e., N's)
    """

    nStr = ''.join(NUCLEOTIDES.keys())
    p    = '^[' + nStr + ']+$'
    return re.search(p, kmerPair[0])

def _insertZeroCountPairs(kmerPairs, kmerLength):

    """
    Description:
        Inserts (K, 0) pairs into a list of tuples. (K, 0) pairs
        refer to kmer sequences with zero counts.

        **********
        *** Adding zero counts in this way is very slow!!!
        **********

    Args:
        kmerPairs (list):
            List of tuples containing the counts of kmer sequences
            of length K. Tuples are (K, V) pairs
            where K = kmer sequence, and V = frequency.

        kmerLength (int):
            Length of kmers. Must be a positive integer.

    Returns:
        kmerPairs (list):
            List of tuples containing the counts of every possible
            kmer sequence of length K. Tuples are (K, V) pairs
            where K = kmer sequence, and V = frequency.
    """

    ## Seems to be (slightly) faster than using set difference
    allKmerSeqs    = getExpectedSequences(kmerLength)
    currKmerSeqs   = [x[0] for x in kmerPairs]
    remainingKmers = [(kmer, 0) for kmer in allKmerSeqs
                      if kmer not in currKmerSeqs]
    kmerPairs      = kmerPairs + remainingKmers
    return kmerPairs

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
