#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import math

# External imports
from bokeh.models import HoverTool
import datashader as ds
import holoviews as hv
from holoviews import opts
from holoviews.operation.datashader import datashade, dynspread
from holoviews.operation import decimate
import pandas as pd

# Internal imports
from .constants import *
from ..ml.algorithm.constants import *
from ..kmer.constants import *
from ..util import spark

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

class Figure():

    def __init__(self):
        self.layout = None

    def buildComponents(self):
        pass

    def assembleComponents(self):
        pass

#------------------------------------------------------------#

class DistributionFigure(Figure):

    def __init__(self, meltedKmerFreq):

        '''
        Args:
            meltedKmerFreq (pd.DataFrame):
                     filename kmer  proportion
                0  file_1.txt    A   31.686082
                1  file_2.txt    A   28.959431
                2  file_1.txt    C   18.313918
                3  file_2.txt    C   21.040569
        '''

        Figure.__init__(self)
        hv.extension('bokeh')

        self.meltedKmerFreq = meltedKmerFreq

    def buildComponents(self):
        self.table = self.getTable()
        self.bars  = self.getBars()

    def assembleComponents(self):
        self.layout = (self.bars + self.table)
        self.layout = self.layout.cols(1)

    def getTable(self):
        pivotKmerFreq = self.meltedKmerFreq.pivot(index=KMER_COL_NAME,
            columns=FILE_COL_NAME, values=PERCENTAGE_COL_NAME)
        pivotKmerFreq.reset_index(inplace=True)

        ## Create table and apply customisation
        table = hv.Table(pivotKmerFreq) \
                  .opts(width=600)
        return table

    def getBars(self):
        ## Create histograms and apply customisation
        dataset = hv.Dataset(self.meltedKmerFreq, KMER_COL_NAME, PERCENTAGE_COL_NAME)
        bars    = dataset.to(hv.Bars, KMER_COL_NAME, PERCENTAGE_COL_NAME,
            groupby=FILE_COL_NAME) \
                         .layout()

        nCols = int(math.sqrt(len(bars)))
        bars  = bars.cols(nCols)

        barOpts = opts.Bars(tools=['hover'], width=400, height=400,
            xrotation=90, xlabel=KMER_COL_NAME, xticks=None,
            ylabel=PERCENTAGE_COL_NAME + " (%)")
        bars.opts(barOpts)
        return bars

#------------------------------------------------------------#

class PCAFigure(Figure):

    ## Maximum number of points that will be plotted
    MAX_POINTS = 1000

    def __init__(self, vStyle):
        Figure.__init__(self)

        self.vStyle = vStyle
        self.initPlottingLibrary()

    def is2D(self):
        if (len(PCA_DATA_COL_NAMES) == 2):
            return True
        return False

    def initPlottingLibrary(self):
        if (self.is2D()):
            hv.extension('bokeh')

        else:
            hv.extension('plotly')

    def getDefaultOptions(self):
        if (self.is2D()):
            options = [opts.Scatter(tools=['hover'], width=700, height=700),
                       opts.Bivariate(tools=['hover'], width=700, height=700),
                       opts.HexTiles(tools=['hover'], width=700, height=700),
                       opts.Image(tools=['hover'], width=700, height=700)]
        else:
            options = [opts.Scatter3D(width=700, height=700)]

        return options

    def splitDataset(self, pcaDataset):
        for i in range(0, len(pcaDataset), self.MAX_POINTS):
            pcaPoints = pcaDataset.iloc[i:i + self.MAX_POINTS, :]
            yield pcaPoints

    def getScatters(self, pcaDataset, colGroup=[]):
        if (self.is2D()):
            scatters  = pcaDataset.to(hv.Scatter,
                 PCA_DATA_COL_NAMES, groupby=colGroup)
        else:
            scatters = pcaDataset.to(hv.Scatter3D,
                PCA_DATA_COL_NAMES, groupby=colGroup)

        return scatters

    def getBivariate(self, pcaDataset, colGroup=[]):
        if (self.is2D()):
            bivariate = pcaDataset.to(hv.Bivariate,
                PCA_DATA_COL_NAMES, groupby=colGroup)

        else:
            raise NotImplementedError("3D Bivariate not implemented.")

        return bivariate

    def getHexTiles(self, pcaDataset):
        if (self.is2D()):
            hextiles = pcaDataset.to(hv.HexTiles,
                PCA_DATA_COL_NAMES, groupby=FILE_COL_NAME)

        else:
            raise NotImplementedError("3D HexTiles not implemented.")

        return hextiles

#------------------------------------------------------------#

class ClassificationFigure(PCAFigure):

    def __init__(self, rKmerPca, tKmerPca, vStyle):

        '''
        Args:
            rKmerPca (pd.DataFrame):
                               id    filename       PCA1       PCA2
                0  10:70096:80096  file_1.txt  -8.682768  -2.970983
                1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                        PCA3 [OPTIONAL]
                0  -2.970983
                1  -3.311564

            tKmerPca (pd.DataFrame)

            vStyle (int)
        '''

        PCAFigure.__init__(self, vStyle)

        self.rPcaDataset = hv.Dataset(rKmerPca, PCA_DATA_COL_NAMES)
        self.tPcaDataset = hv.Dataset(tKmerPca, PCA_DATA_COL_NAMES)

    def buildComponents(self):
        rScat     = self.getScatters(self.rPcaDataset, FILE_COL_NAME)
        rScatOver = rScat.relabel(REF_LABEL).overlay()
        tScat     = self.getScatters(self.tPcaDataset, FILE_COL_NAME)
        tScatOver = tScat.relabel(TARGET_LABEL).overlay()
        options   = self.getDefaultOptions()

        ## Scatter (for small data sets)
        if (self.vStyle == 1):
            if (self.is2D()):
                options = options \
                    + [opts.Scatter(REF_LABEL, marker='s', size=7, alpha=0.4),
                       opts.Scatter(TARGET_LABEL, size=3, show_legend=False)]

            else:
                options = options \
                    + [opts.Scatter3D(REF_LABEL, marker='square', size=3),
                       opts.Scatter3D(TARGET_LABEL, size=3, show_legend=False)]

            tScatOver.opts(options)
            rScatOver.opts(options)
            overlay = decimate(tScatOver) * rScatOver

        ## Scatter & Bivariate for visualising density
        elif(self.vStyle == 2):
            if (DLABEL_COL_NAME not in self.tPcaDataset.data.columns):
                raise KeyError("Requires density labels")

            if (self.is2D()):
                options = options \
                    + [opts.Scatter(REF_LABEL, marker='s', size=3, alpha=0.4),
                       opts.Scatter(TARGET_LABEL, size=7, cmap='Set1', alpha=0.2,
                           color=DLABEL_COL_NAME, show_legend=False),
                       opts.Bivariate(show_legend=False, filled=True)]
            else:
                raise NotImplementedError("3D not implemented.")

            rBi     = self.getBivariate(self.rPcaDataset, FILE_COL_NAME)
            rBiOver = rBi.overlay()
            tScatOver.opts(options)
            rScatOver.opts(options)
            rBiOver.opts(options)
            overlay = rBiOver * rScatOver * decimate(tScatOver)

        self.plots = overlay

    def assembleComponents(self):
        self.layout   = self.plots
        # self.layout = hv.HoloMap(self.plots, kdims=['subset'])

        # ## [OPTIONAL] We can switch up the layout of the plots
        # ## Cannot use holomap for 3D output
        # nCols       = int(math.sqrt(len(self.layout)))
        # self.layout = hv.NdLayout(self.layout).cols(nCols)

#------------------------------------------------------------#

class PredictionFigure(PCAFigure):

    POSITIONS_ID_LENGTH = 8

    def __init__(self, tKmerPca, vStyle):

        '''
        Args:
            rKmerPca (pd.DataFrame):
                               id    filename       PCA1       PCA2
                0  10:70096:80096  file_1.txt  -8.682768  -2.970983
                1  10:61911:71911  file_1.txt  -3.311564  -6.471915

                        PCA3 [OPTIONAL]
                0  -2.970983
                1  -3.311564

            tKmerPca (pd.DataFrame)

            vStyle (int)
        '''

        PCAFigure.__init__(self, vStyle)

        tKmerPca         = self.addReadLabelColumn(tKmerPca)
        self.tPcaDataset = hv.Dataset(tKmerPca, PCA_DATA_COL_NAMES)

    def buildComponents(self):
        from holoviews import dim         ## Requires python 3.7; not 3.5
        tScat   = self.getScatters(self.tPcaDataset)
        options = self.getDefaultOptions()

        ## Scatter (for small data sets)
        if (self.vStyle == 1):
            tScat.opts(options)
            overlay = tScat

        ## Scatter (for large data sets)
        elif (self.vStyle == 2):
            overlay = datashade(tScat)
            overlay.opts(width=700, height=700)

        ## Scatter for visualising clusters
        elif (self.vStyle == 3):
            if (CLABEL_COL_NAME not in self.tPcaDataset.data.columns):
                raise KeyError("Requires cluster labels")

            if (self.is2D()):
                options = options \
                    + [opts.Scatter(size=7,
                           color=CLABEL_COL_NAME, cmap='Category10')]
            else:
                options = options \
                    + [opts.Scatter3D(size=7,
                           color=CLABEL_COL_NAME, cmap='Category10')]

            tScat.opts(options)
            overlay = tScat

        ## Scatter & Bivariate for visualising density
        elif (self.vStyle == 4):
            if (DPROB_COL_NAME not in self.tPcaDataset.data.columns):
                raise KeyError("Requires density labels")

            if (self.is2D()):
                options = options \
                    + [opts.Bivariate(show_legend=False, filled=True),
                       opts.Scatter(size=TYPE_COL_NAME, alpha=0.2,
                           color=DPROB_COL_NAME, colorbar=True,
                           cmap='Inferno')]

            else:
                raise NotImplementedError("3D not implemented.")

            tBi = self.getBivariate(self.tPcaDataset)
            tScat.opts(options)
            tBi.opts(options)
            overlay = tBi * decimate(tScat)

        ## Scatter for visualising outliers
        elif (self.vStyle == 5):
            if (OLABEL_COL_NAME not in self.tPcaDataset.data.columns):
                raise KeyError("Requires outlier labels")

            if (self.is2D()):
                options = options \
                    + [opts.Scatter(size=7,
                           color=OLABEL_COL_NAME, cmap='Category10')]
            else:
                options = options \
                    + [opts.Scatter3D(size=7,
                           color=OLABEL_COL_NAME, cmap='Category10')]

            tScat.opts(options)
            overlay = tScat

        self.plots = overlay

    def assembleComponents(self):
        self.layout   = self.plots
        # self.layout = hv.HoloMap(self.plots, kdims=['subset'])

        # ## [OPTIONAL] We can switch up the layout of the plots
        # ## Cannot use holomap for 3D output
        # nCols       = int(math.sqrt(len(self.layout)))
        # self.layout = hv.NdLayout(self.layout).cols(nCols)

    def addReadLabelColumn(self, tKmerPca):
        if (self.vStyle == 4):
            positions = tKmerPca[ID_COL_NAME].str.split(':', expand=True)
            if (len(positions.columns) == self.POSITIONS_ID_LENGTH):
                tKmerPca[TYPE_COL_NAME] = positions.apply(self.getReadLabel, axis=1)

        return tKmerPca

    def getReadLabel(self, row):

        '''
            s & t      |----------|==========|----------|
            r                       |-----|
            r                |-----|        |-----|
            r            |-----|                |-----|
        '''

        sStart = int(row[1])
        sEnd   = int(row[2])
        tStart = int(row[4])
        tEnd   = int(row[5])
        rStart = int(row[6])
        rEnd   = int(row[7])

        isTarget  = (rStart >= tStart and rEnd <= tEnd)
        isPartial = (tStart >= rStart and tStart <= rEnd) \
                    or (tEnd >= rStart and tEnd <= rEnd)
        isSource  = (not isTarget and not isPartial)

        if (isTarget):
            return 10

        elif (isPartial):
            return 10

        else:
            return 3

        # ## Scatter plot (split)
        # ## Colour by cluster and marker by data set
        # ## Because clustering doesn't work well, we can ignore this step
        # if (self.vStyle == 1):
        #     pcaPoints  = self.splitDataset(self.pcaDataset)
        #     overlays   = map(self.getOverlay1, pcaPoints)
        #     options    = map(self.getStyleOptions1, pcaPoints)
        #     self.plots = [x.opts(y) for x, y in zip(overlays, options)]

        # def getOverlay1(self, pcaDataset):
        #     scatters = self.getScatters(pcaDataset)
        #     overlay  = scatters.overlay()
        #     return overlay

        # self.plots  = {idx : o for idx, o in enumerate(self.plots)}
        # self.layout = hv.HoloMap(self.plots, kdims=['subset']).collate()

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
