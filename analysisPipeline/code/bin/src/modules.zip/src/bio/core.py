#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import random
import re
from functools import reduce

# External imports
from Bio.SeqRecord import SeqRecord

# Internal imports

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def getFaRecord(fastaId, faRecs, exception=True):
    if (fastaId is not None):
        f = lambda x: x.id == fastaId
        faRec = list(filter(f, faRecs))

    else:
        ## Choose a random chromosome
        randFaIdx = random.randint(0, len(faRecs) - 1)

        ## Choose a random position in the chromosome
        ## We only look at the forward strand positions
        faRec = [faRecs[randFaIdx]]

    return faRec

def createRandomIntervalSeqRecord(faRec, windowSize, limits=None):
    seq  = ""

    ## Get a random sequence that doesn't contain N's
    while (len(seq) == 0 or seq.count("N") != 0):
        if (limits is not None):
            randStartPos = random.randint(limits[0], limits[1])
            
        else:
            idx          = len(faRec.seq) - windowSize - 1
            randStartPos = random.randint(0, idx)

        endPos = randStartPos + windowSize
        seq    = faRec.seq[randStartPos:endPos]

    seqId = "{id}:{startPos}:{endPos}".format(id=faRec.id,
        startPos=randStartPos, endPos=endPos)
    seqRec = createSeqRecord(seq, seqId, faRec.description)
    return seqRec

def getRandomFeatureRecord(featureId, featureDB):
    features = []

    if (featureId is not None):
        features = list(featureDB.features_of_type(featureId))

    else:
        ## We want regions that are entirely non-coding
        ## i.e., intergenic, telomeres, centromere
        features = list(featureDB.features_of_type('inter_gene_gene'))

        ## If we have already calculated interfeatures,
        ## then we shouldn't do it again
        if (len(features) == 0):
            featureDB = addInterfeatures(featureDB)
            features  = list(featureDB.features_of_type('inter_gene_gene'))

    randFeatureIdx = random.randint(0, len(features) - 1)
    randFeatureRec = features[randFeatureIdx]
    return randFeatureRec

def createFeatureSeqRecord(faRec, featureRec):
    if ('Name' not in featureRec.attributes):
        raise NotImplementedError('No name detected')

    fId      = featureRec.attributes['Name'][0]
    fType    = featureRec.featuretype
    startPos = featureRec.start
    endPos   = featureRec.stop
    strand   = featureRec.strand

    seq   = faRec.seq[startPos:endPos]
    seq   = seq.reverse_complement() if (strand == '-') else seq
    seqId = "{id}:{fType}:{fId}:{startPos}:{endPos}".format(
        id=faRec.id, fId=fId, fType=fType, 
        startPos=startPos, endPos=endPos)

    seqRec = createSeqRecord(seq, seqId, faRec.description)
    return seqRec

def getHybridSeqRecord(faRecs, sId, tId):
    seqRec = None

    ## Get a hybrid sequence that doesn't hybridise with itself
    while (seqRec is None):
        sFaRec = getFaRecord(sId, faRecs)
        tFaRec = getFaRecord(tId, faRecs)
        if (len(sFaRec) == 0 or len(tFaRec) == 0):
            raise IndexError("Invalid FASTA ID")

        if (sFaRec[0].id == tFaRec[0].id):
            seqRec = None

        else:
            seqRec = createRandomHybridSeqRecord(sFaRec[0], tFaRec[0])

    return seqRec

def createRandomHybridSeqRecord(sFaRec, tFaRec):
    idx          = len(tFaRec.seq) - 1
    randStartPos = random.randint(0, idx)
    endPos       = randStartPos + len(sFaRec.seq)

    ## Randomly insert the source sequence into the target sequence
    seq    = tFaRec.seq[:randStartPos] + sFaRec.seq + tFaRec.seq[randStartPos:]
    seqId  = "{tId}:{tStartPos}:{tEndPos}:{sId}:{sStartPos}:{sEndPos}".format(
        tId=tFaRec.id, tStartPos=str(0), tEndPos=str(len(tFaRec.seq) - 1), 
        sId=sFaRec.id, sStartPos=randStartPos, sEndPos=endPos)
    seqRec = createSeqRecord(seq, seqId, tFaRec.description)
    return seqRec

def createFastqSeqRecord(hybridSeqRec, windowSize, limits=None):
    seqRec  = createRandomIntervalSeqRecord(hybridSeqRec, windowSize, limits=limits)
    qValues = [91] * len(seqRec.seq)    ## Random number for a quality
    seqRec.letter_annotations['phred_quality'] = qValues
    print(seqRec.id)
    return seqRec

def createIntervalSeqRecord(faRec, startPos, endPos):
    seq    = faRec.seq[startPos:endPos]
    seqId  = "{startPos}-{endPos}".format(startPos=str(startPos),
        endPos=str((endPos - 1)))
    seqRec = createSeqRecord(seq, seqId, faRec.description)
    return seqRec

#------------------- Private Classes & Functions ------------#

def createSeqRecord(seq, seqId, seqDescription):
    seqRec = SeqRecord(seq, id=seqId, description=seqDescription)
    return seqRec

def addInterfeatures(featureDB):
    ## GFFutils featureDB.interfeatures() does not work when 
    ## there are features from different chromosomes or strand
    seqIdList  = getSeqIds(featureDB)
    strandList = getStrands(featureDB)
    features   = list(featureDB.features_of_type('gene'))

    ## There is an issue in that we are only looking at regions
    ## between gene features. Such regions MAY or MAY NOT contain
    ## features (i.e., non-coding exons, tRNAs etc...).
    ## In these cases, we need to either remove or shorten each feature
    for s in strandList:
        for seqId in seqIdList:
            f = lambda x: x.strand == s and x.seqid == seqId
            featuresSublist = filter(f, features)
            interfeatures   = featureDB.interfeatures(featuresSublist)
            interfeatures   = map(updateInterfeatureName, interfeatures)
            featureDB.update(interfeatures)

    return featureDB

def getSeqIds(featureDB):
    seqIdQuery  = 'SELECT DISTINCT seqid FROM features;'
    seqIdResult = featureDB.execute(seqIdQuery)

    f = lambda x, y: list(x) + list(y)
    seqIdList = list(reduce(f, seqIdResult))
    return seqIdList

def getStrands(featureDB):
    strandQuery  = 'SELECT DISTINCT strand FROM features \
                    WHERE strand != ".";'   ## Some features don't have a strand
    strandResult = featureDB.execute(strandQuery)

    f = lambda x, y: list(x) + list(y)
    strandList = list(reduce(f, strandResult))
    return strandList

def updateInterfeatureName(interfeature):
    f = lambda x: re.sub('^.*:', '', x)
    names = list(map(f, interfeature.attributes['ID']))

    name  = ['_'.join(names)]
    interfeature.attributes['Name'] = name
    return interfeature

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
