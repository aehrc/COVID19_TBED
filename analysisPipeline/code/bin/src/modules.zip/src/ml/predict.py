#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports

# Internal imports
from .common import rotate

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(tKmerPdf, **kwargs):
    print("Running")
    # tKmerPdf = rotate(tKmerPdf)



def predict(tKmerId, tFreq, **kwargs):
    ## Dimensionality reduction with PCA (or its variants)
    (tPca, tPcaColNames) = runPca(tFreq)
    tCols                = [tPca]
    tColNames            = [tPcaColNames]

    ## Run other types of analyses to contextualise the points
    if ('cFlag' in kwargs and kwargs['cFlag']):
        ## Clustering really doesn't work well...
        ## Primarily has to do with the fact our clusters are 'continuous'
        ## and not really distinct from one another
        ## plotPerf=True to visualise clustering performance
        (tCluster, tClusterColNames) = runClustering(tPca)
        tCols.append(tCluster)
        tColNames.append(tClusterColNames)

    if ('dFlag' in kwargs and kwargs['dFlag']):
        ## Calculating density of an entire data set is really slow!
        ## We need a new approach
        (tDen, tDenColNames, bws) = runDensityEstimation(tKmerId, tPca)
        tCols.append(tDen)
        tColNames.append(tDenColNames)

    if ('eFlag' in kwargs and kwargs['eFlag']):
        ## Find outliers in the data set
        (tOutlier, tOutColNames) = runOutlierDetection(tPca)
        tCols.append(tOutlier)
        tColNames.append(tOutColNames)

    ## Concatenate the data into a single dataframe
    tKmerPca = formatAnalysis(tKmerId, tCols, tColNames)
    tKmerPca = prototypeAnalysis(tKmerPca, tFreq)
    return tKmerPca


#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
