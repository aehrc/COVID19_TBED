#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import numpy as np
import pandas as pd

# Internal imports
from ..kmer.constants import *
from . import algorithm

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def classify(rKmerId, rKmerCount, tKmerId, tKmerCount, **kwargs):
    ## Dimensionality reduction with PCA (or its variants)
    print("Running PCA")
    (rPca, tPca, pcaColNames) = algorithm.pca.run(rKmerCount, tKmerCount)
    rCols     = [rPca]
    tCols     = [tPca]
    rColNames = [pcaColNames]
    tColNames = [pcaColNames]

    ## Run other types of analyses to contextualise the points
    if (kwargs.get('dFlag')):
        (rDen, tDen, tDenColNames, bws) = algorithm.density.run(rKmerId, rPca, tPca)
        rCols.append(rDen)
        tCols.append(tDen)
        rColNames.append([tDenColNames[0]])
        tColNames.append([tDenColNames[1]])

    rKmerPca = formatAnalysis(rKmerId, rCols, rColNames)
    tKmerPca = formatAnalysis(tKmerId, tCols, tColNames)
    return (rKmerPca, tKmerPca)

def predict(tKmerId, tKmerCount, **kwargs):
    ## Dimensionality reduction with PCA (or its variants)
    print("Running PCA")
    (tPca, tPcaColNames) = algorithm.pca.run(tKmerCount)
    tCols                = [tPca]
    tColNames            = [tPcaColNames]

    ## Run other types of analyses to contextualise the points

    if (kwargs.get('cFlag')):
        ## Clustering really doesn't work well...
        ## Primarily has to do with the fact our clusters are 'continuous'
        ## and not really distinct from one another
        ## plotPerf=True to visualise clustering performance
        print("Running clustering")
        (tCluster, tClusterColNames) = algorithm.cluster.run(tPca)
        tCols.append(tCluster)
        tColNames.append(tClusterColNames)

    if (kwargs.get('dFlag')):
        ## Calculating density of an entire data set is really slow!
        ## We need a new approach
        print("Running density estimation")
        (tDen, tDenColNames, bws) = algorithm.density.run(tKmerId, tPca)
        tCols.append(tDen)
        tColNames.append(tDenColNames)

    if (kwargs.get('eFlag')):
        ## Find outliers in the data set
        print("Running outlier detection")
        (tOutlier, tOutColNames) = algorithm.outlier.run(tPca)
        tCols.append(tOutlier)
        tColNames.append(tOutColNames)

    ## Concatenate the data into a single dataframe
    tKmerPca = formatAnalysis(tKmerId, tCols, tColNames)
    # tKmerPca = prototypeAnalysis(tKmerPca, tKmerCount)
    return tKmerPca

#------------------- Private Classes & Functions ------------#

def formatAnalysis(kmerId, cols, colNames):
    colNames = [c for l in colNames for c in l]
    cols     = np.hstack(cols)
    cols     = pd.DataFrame(cols, columns=colNames)
    kmerPca  = pd.concat([kmerId, cols], axis=1)
    return kmerPca

def prototypeAnalysis(tKmerPca, tKmerCount):
    isOutlier = tKmerPca[OLABEL_COL_NAME] == -1
    outliers  = tKmerPca.loc[isOutlier]
    oKmerId   = outliers.iloc[:, 0:2]
    oFreq     = tKmerCount.iloc[outliers.index, :]

    oKmerId.reset_index(inplace=True, drop=True)
    oFreq.reset_index(inplace=True, drop=True)

    (oPca, oPcaColNames) = runPca(oFreq)
    oCols                = [oPca]
    oColNames            = [oPcaColNames]

    (oCluster, oClusterColNames) = runClustering(oPca)
    oCols.append(oCluster)
    oColNames.append(oClusterColNames)

    oKmerPca = formatAnalysis(oKmerId, oCols, oColNames)
    return oKmerPca

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
