#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, FastICA
from sklearn.manifold import Isomap, TSNE

# Internal imports
from ...util import spark
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(rKmerCount, *tKmerCount):
    pipe  = getPipeline()

    ## We are only explaining about 70% of the variance
    ## with 2D PCA (not great, but works relatively OK)
    rPca  = pipe.fit_transform(rKmerCount)
    # print(pipe.steps[1][1].explained_variance_ratio_)

    if (len(tKmerCount) != 0):
        tPca = pipe.transform(tKmerCount[0])
        return (rPca, tPca, PCA_DATA_COL_NAMES)

    return (rPca, PCA_DATA_COL_NAMES)

#------------------- Private Classes & Functions ------------#

def getPipeline():
    ## Set up PCA pipeline
    ## 1. Scale variables
    ## 2. Apply PCA
    pipe = Pipeline([('scaler', StandardScaler()),
                     ('reducer', PCA(n_components=N_PCA_COMPONENTS)),
                     ('minmax', MinMaxScaler())     
                     ## Scale the points again so that we can compare plots
                     ## across different Kmers.
                     # ('reducer', FastICA(n_components=N_PCA_COMPONENTS))
                     # ('reducer', Isomap(n_components=N_PCA_COMPONENTS))
                     # ('reducer', TSNE(n_components=N_PCA_COMPONENTS))
                     ])
    return pipe

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
