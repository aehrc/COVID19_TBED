#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import numpy as np
from sklearn.covariance import EllipticEnvelope
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import OneClassSVM

# Internal imports
from .constants import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def run(pca):
    pipe  = getPipeline()

    ## Degree doesnt change the classification by much
    ## OneClassSVM linear kernal is decent but essentially a splits the plot
    ## EllipticEnvelope works nicely!
    oLabels = pipe.fit_predict(pca)
    oLabels = np.reshape(oLabels, (-1, 1))
    return (oLabels, [OLABEL_COL_NAME])

#------------------- Private Classes & Functions ------------#

def getPipeline():
    ## Set up PCA pipeline
    ## 1. Scale variables
    ## 2. Apply PCA
    pipe = Pipeline([('scaler', StandardScaler()),
                     ('outlier', EllipticEnvelope(contamination=0.2))
                     # ('outlier', OneClassSVM(kernel='poly', max_iter=5000, degree=6))
                     # ('outlier', IsolationForest())
                     # ('outlier', LocalOutlierFactor())
                     ])
    return pipe

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
