#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import numpy as np
import pandas as pd

# Internal imports
from .algorithm.constants import OLABEL_COL_NAME
from .algorithm import runClustering
from .algorithm import runDensityEstimation
from .algorithm import runOutlierDetection
from .algorithm import runPca

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def classify(rKmerId, rFreq, tKmerIds, tFreqs, **kwargs):
    (rPca, tPcas, pcaColNames) = runPca(rFreq, *tFreqs)
    rCols     = [rPca]
    tCols     = [tPcas]
    rColNames = [pcaColNames]
    tColNames = [pcaColNames]

    ## Run other types of analyses to contextualise the points
    if ('dFlag' in kwargs and kwargs['dFlag']):
        (rDen, tDens, tDenColNames, bws) = runDensityEstimation(rKmerId, rPca, *tPcas)
        rCols.append(rDen)
        tCols.append(tDens)
        rColNames.append([tDenColNames[0]])
        tColNames.append([tDenColNames[1]])

    rKmerPca = formatAnalysis(rKmerId, rCols, rColNames)

    ## Concatenate the data into a single dataframe
    tKmerPcas = formatAnalysisList(tKmerIds, tCols, tColNames)
    tKmerPca  = pd.concat(tKmerPcas, ignore_index=True)
    return (rKmerPca, tKmerPca)

def predict(tKmerId, tFreq, **kwargs):
    ## Dimensionality reduction with PCA (or its variants)
    (tPca, tPcaColNames) = runPca(tFreq)
    tCols                = [tPca]
    tColNames            = [tPcaColNames]

    ## Run other types of analyses to contextualise the points
    if ('cFlag' in kwargs and kwargs['cFlag']):
        ## Clustering really doesn't work well...
        ## Primarily has to do with the fact our clusters are 'continuous'
        ## and not really distinct from one another
        ## plotPerf=True to visualise clustering performance
        (tCluster, tClusterColNames) = runClustering(tPca)
        tCols.append(tCluster)
        tColNames.append(tClusterColNames)

    if ('dFlag' in kwargs and kwargs['dFlag']):
        ## Calculating density of an entire data set is really slow!
        ## We need a new approach
        (tDen, tDenColNames, bws) = runDensityEstimation(tKmerId, tPca)
        tCols.append(tDen)
        tColNames.append(tDenColNames)

    if ('eFlag' in kwargs and kwargs['eFlag']):
        ## Find outliers in the data set
        (tOutlier, tOutColNames) = runOutlierDetection(tPca)
        tCols.append(tOutlier)
        tColNames.append(tOutColNames)

    ## Concatenate the data into a single dataframe
    tKmerPca = formatAnalysis(tKmerId, tCols, tColNames)
    tKmerPca = prototypeAnalysis(tKmerPca, tFreq)
    return tKmerPca

def prototypeAnalysis(tKmerPca, tFreq):
    isOutlier = tKmerPca[OLABEL_COL_NAME] == -1
    outliers  = tKmerPca.loc[isOutlier]
    oKmerId   = outliers.iloc[:, 0:2]
    oFreq     = tFreq.iloc[outliers.index, :]

    oKmerId.reset_index(inplace=True, drop=True)
    oFreq.reset_index(inplace=True, drop=True)

    (oPca, oPcaColNames) = runPca(oFreq)
    oCols                = [oPca]
    oColNames            = [oPcaColNames]

    (oCluster, oClusterColNames) = runClustering(oPca)
    oCols.append(oCluster)
    oColNames.append(oClusterColNames)

    oKmerPca = formatAnalysis(oKmerId, oCols, oColNames)
    return oKmerPca

#------------------- Private Classes & Functions ------------#

## Different functions for slightly different inputs
## Can probably be generalised better...
def formatAnalysisList(kmerIds, cols, colNames):
    colNames = [c for l in colNames for c in l]
    cols     = [np.hstack(c) for c in zip(*cols)]
    cols     = [pd.DataFrame(c, columns=colNames) for c in cols]
    [kmerId.reset_index(inplace=True, drop=True) for kmerId in kmerIds]
    kmerPcas = [pd.concat([kmerId, col], axis=1)
                for kmerId, col in zip(kmerIds, cols)]
    return kmerPcas

def formatAnalysis(kmerId, cols, colNames):
    colNames = [c for l in colNames for c in l]
    cols     = np.hstack(cols)
    cols     = pd.DataFrame(cols, columns=colNames)
    kmerPca  = pd.concat([kmerId, cols], axis=1)
    return kmerPca

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
